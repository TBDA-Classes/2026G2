"""Sprint 3 Task 1 — run the CHOSEN linear configuration once on the test week.

    python task1_linear_test.py [--data derived/Storey1_hourly_v1.1.parquet]

No tuning here: the settings are read from models/task1_linear_config.json (written by task1_linear.py on
validation only). The model is refitted on exactly the same training rows (linear fits are deterministic).
Writes results/task1_linear_test_predictions.parquet and results/task1_linear_test_comparison.csv
(all 5 models on the same test hours, using results/task8_test_predictions.parquet).
"""
import argparse
import json
from pathlib import Path

import pandas as pd

import config as C
from task7_pipeline import sha256_file
from task7_baselines import load_derived, forecast_tasks, score
from task8_model import _series_frames, training_frame, build_features, predictions_frame, scaled_mae_by_series
from task1_linear import ML, LinearForecaster

ap = argparse.ArgumentParser()
ap.add_argument("--data", type=Path, default=Path(C.DERIVED_PATH))
a = ap.parse_args()

cfg = json.loads(Path("models/task1_linear_config.json").read_text())
if sha256_file(a.data) != cfg["dataset"]["sha256"]:
    raise SystemExit("dataset differs from the one the configuration was chosen on")

h = load_derived(a.data)
S = cfg["series"]
frames = _series_frames(h)
preds, rows = [], []
for hz, c in cfg["horizons"].items():
    cut = pd.Timestamp(c["fit_cutoff_utc"])
    F, scale = training_frame(h, hz, S, cut, frames=frames)
    assert int(F["y_scaled"].notna().sum()) == c["training_rows"]
    m = LinearForecaster(c["mode"], c["loss"], c["alpha"], S).fit(F)
    T = build_features(h, forecast_tasks(h, hz, "test", S), scale, frames=frames)
    P = predictions_frame(T, m.predict(T), ML)
    preds.append(P)
    rows.append({"horizon": hz, "test_scaled_MAE": scaled_mae_by_series(P, scale).mean()})
    print(f"{hz}: test score {rows[-1]['test_scaled_MAE']:.4f}")

TP = pd.concat(preds, ignore_index=True)
TP.to_parquet("results/task1_linear_test_predictions.parquet", index=False)
t8 = pd.read_parquet("results/task8_test_predictions.parquet")
models5 = ["B1_last_week", "B2_weekday_hour_median", "B3_persistence", "ML_GBM", ML]
score(pd.concat([t8, TP], ignore_index=True), "energy_Wh", models=models5).to_csv(
    "results/task1_linear_test_comparison.csv", index=False)
print("wrote results/task1_linear_test_predictions.parquet, results/task1_linear_test_comparison.csv")
