# Sprint 3 Task 1 — linear regression model (Mert & Maxime)

```
pip install -r requirements.txt
python task1_linear.py          # ~1 min, chooses the settings on validation
python task1_linear_test.py     # runs the chosen settings ONCE on the test week
```

Put `task1_linear.py` in the Task 7&8 folder (next to `task8_model.py`); it imports from it.

## Setup (same as Task 8, so the comparison is fair)
- Same hourly dataset v1.1, same 8 circuits, same train (19 Aug – 21 Sep 2025) and validation week (22–28 Sep).
- Same forecasts: +1h, +6h and day-ahead (issued at 00:00 Madrid).
- Same inputs as the GBM (`build_features`): last value, 24 h / 168 h means, same hour 24 h and 168 h ago, 4-week median, hour, weekday, hours ahead. Values divided by each circuit's training mean.
- Linear models need complete inputs: missing inputs get the **training** median plus a 0/1 "was missing" column; numbers are standardised; hour and weekday are one-hot; the pooled model gets one dummy per circuit.
- Two loss functions: **ridge** (least squares + L2 penalty) and **LAD** (median regression, optimises absolute error = MAE).
- Choice on validation with the Task 8 rule: lowest mean over circuits of (MAE ÷ circuit training mean). **The test week is not used.**

## Chosen per horizon
| Horizon | Setup | Loss | alpha | Validation score |
|---|---|---|---|---|
| +1h | per circuit | LAD | 0.001 | 0.278 |
| +6h | pooled | LAD | 0.001 | 0.359 |
| day-ahead | pooled | LAD | 0.001 | 0.357 |

LAD beats ridge everywhere (e.g. +1h 0.28 vs 0.32): least squares is pulled by a few very large hours, absolute error is not.

## Validation results, same hours for all models (scaled MAE, lower is better)
| Horizon | B1 last week | B2 weekday-hour median | B3 persistence | GBM (Task 8) | **Linear** |
|---|---|---|---|---|---|
| +1h | 0.578 | 0.427 | 0.290 | **0.246** | 0.272 |
| +6h | 0.578 | 0.429 | 0.460 | 0.355 | **0.350** |
| day-ahead | 0.578 | 0.427 | 0.367 | 0.384 | **0.348** |

- The linear model beats B2 on 7 of 8 circuits at every horizon.
- +1h: GBM is better (0.246 vs 0.272).
- +6h and day-ahead: the linear model is level with or slightly better than GBM on validation; it is the best model day-ahead.
- Validation is one week; these are small differences. Only the test week (Task 4) can confirm them.

## Test week (29 Sep – 5 Oct), run once after the choice was fixed
Scaled MAE, same hours for all models. "Without 2 events" leaves out the two whole circuits where the Task 8 README found the events (NE|HVAC and NW|Emerg. Lighting), so it averages over 6 circuits. Task 8 left out only the event hours, so these numbers are not the same as its table.

| Horizon | B1 | B2 | B3 | GBM | **Linear** | Linear, without 2 events | GBM, without 2 events | best other, without 2 events |
|---|---|---|---|---|---|---|---|---|
| +1h | 1.266 | 1.166 | **0.930** | 1.032 | 2.080 | **0.294** | 0.309 | B3 0.298 |
| +6h | 1.267 | 1.167 | 1.887 | **1.175** | 1.276 | **0.437** | 0.481 | B2 0.465 |
| day-ahead | 1.267 | 1.166 | **1.162** | 1.173 | 1.260 | **0.439** | 0.477 | B2 0.465 |

- **Weak point found:** NE|HVAC normally uses ~3 Wh per hour, but ran at ~690 Wh on 3 Oct. After that, the linear model kept predicting ~180 Wh for a day, because its inputs include the mean of the last 24 h and 168 h, and a straight line multiplies that jump. Its +1h MAE on NE|HVAC is 32.4 Wh vs 10.3 for GBM. Trees cannot extrapolate like this, so GBM stays calm.
- **Without these 2 events the linear model is the best model at every horizon** (6 circuits).
- We did **not** change the model after seeing the test week (sprint rule 3). Possible fix for Sprint 4, to be checked on validation: limit inputs to the training range (clipping), or use the change from the last value as the target.

## Files
- `results/task1_linear_tuning_log.csv` — score of all 14 configurations per horizon (42 in total)
- `results/task1_linear_validation_predictions.parquet` — all validation forecasts
- `results/task1_linear_validation_results.csv` — MAE / RMSE per circuit
- `results/task1_linear_comparison.csv` — MAE / RMSE of all 5 models on the same validation hours
- `results/task1_linear_test_comparison.csv`, `task1_linear_test_predictions.parquet`, `task1_linear_test_summary.txt` — the same for the test week
- `models/task1_linear_config.json` — chosen settings, dataset checksum, versions

## Open points
1. The best alpha is at the edge of the grid (0.001 for LAD): try 0.01 and 0.1 too.
2. The NE|HVAC jump (see test week): try clipping the inputs on validation.
