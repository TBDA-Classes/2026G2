# Task 7 — hourly modelling dataset (S05–S11), version 1.1

```
pip install pandas pyarrow holidays openpyxl pytest
python -m pytest -q tests/                      # 26 tests on toy data (14 dataset, 7 baselines, 5 ML model)
python run_task7.py --data data/Storey1_ALL_ZONES_FROZEN_v1.0.csv.xz --out derived
```
Runtime ~20 s. All parameters live in `config.py`. The source file is checked (SHA-256) before and after the run.

| Step | Function | Output |
|---|---|---|
| S05 | `load_frozen(path)` | reads .csv.xz/.gz, verifies manifest SHA-256, adds `utc`, `hour_utc`, `hour_local`, `series_id` |
| S06 | `aggregate_energy_hourly` | `energy_Wh`, `energy_n_obs`, `energy_max_gap_min`, `energy_catch_up`, `energy_tail_gap_min`, `energy_pre_outage`, `energy_valid`, `energy_source` on a complete hourly grid |
| S07 | `hourly_power_current` | `W_mean`, `I_mean` time-weighted, plus `*_cov_min`, `*_n_obs`, `*_valid` |
| S08 | `add_split_and_calendar` | `split`, `hour`, `weekday`, `month`, `is_weekend`, `is_holiday` |
| S09 | `save_derived` | `derived/Storey1_hourly_v1.1.parquet` + `_META.json` (refuses to overwrite) |
| S10 | `eligibility` | `derived/S10_eligibility_v1.1_THRESHOLD30.xlsx` (eligible / excluded / sensitivity) |
| S11 | `mae`, `rmse` | `(value, n_valid_pairs)`, ValueError if no pairs |

## Findings from the data
- Only the 2025 regime (2025-08-18 → 2025-10-13) is minute-level, so the pipeline processes only that part. 16 series, because SW|RACK has no 2025 data.
- `energy_Wh` after a gap covers the whole gap (after a 4-min gap the value is ≈ 4 × W/60). Hourly sums therefore stay complete with missing rows. Rows per hour: median 48, max 57, never 60.
- After an outage, one row carries the whole outage (e.g. 10,229 Wh after 1,006 min on 2025-09-17). Hours with a preceding gap > `ENERGY_MAX_GAP` are invalid (`energy_catch_up`). This rule is an addition to the S06 spec.
- **v1.1:** the hour *before* an outage is now also checked. If more than `ENERGY_TAIL_MAX` = 5 min at its end fall inside a long gap, that energy is booked in the later catch-up row, so the hour is invalid (`energy_pre_outage`). 96 hours change, all in training; eligibility is unchanged. v1.0 was rebuilt from the frozen file first and matched exactly.
- After a row without an energy value (`unknown`/`period_start`), the next energy value covers only the time since that row, so gaps are correctly measured to the previous row of any kind.
- S10 result (THRESHOLD 30, Task 6 split): **8 eligible** (all NE + NW, 167/168 validation and 168/168 test hours), **8 excluded** (all SE + SW). SE|Plugs & Sockets is the closest at 88 % / 89 %. At THRESHOLD 20 it would be eligible, at THRESHOLD 50 no series is.
- This differs from Task 6 §4 ("high coverage across NE, NW, SE and SW"). The Task 6 script counts an hour as covered if it has at least one energy value. S10 requires a valid hourly sum (≥ 30 rows, no catch-up). SE/SW have many sparse daytime hours, which is why they fail here.
- SE|Lighting and SW|Lighting have some valid hours where energy ≫ mean W (up to 2,097 Wh at 0.5 W). This is unexplained, and both series are excluded anyway. It should be raised with the data owner.
- Holidays: `holidays` (ES/MD) has none in the 2025 window. Madrid city holidays and UPM closing days (`upm_calendar.xlsx`) are not included.
- No DST change inside the window (next one is 2025-10-26), so every week has exactly 168 hours.

## Parameters (config.py)
- Splits from Task 6 §4, in UTC like `task6_split_design.py`: train 19.08–21.09, validation 22.09–28.09, test 29.09–05.10. 18.08 and everything after 05.10 are `outside`.
- `THRESHOLD = 30` (same value as the Task 6 coverage analysis).
- Still to confirm with the team: `ENERGY_MAX_GAP = 15`, `ENERGY_TAIL_MAX = 5`, `MAX_GAP = 5`, `MIN_COVERAGE_MIN = 30`.
- Not covered here: the historical 2020–2022 split from Task 6 §10. Those data are already hourly and need no S06/S07 aggregation.
