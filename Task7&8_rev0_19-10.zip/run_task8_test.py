"""Task 8 — run the FROZEN models once on the test week and compare with the baselines.

    python run_task8_test.py [--data derived/Storey1_hourly_v1.1.parquet]

Contains no training or tuning code: it only loads the frozen models. It refuses to run if the frozen config is
missing, if the dataset or a model file does not match the checksums recorded at freezing time.
Writes results/task8_test_predictions.parquet, results/task8_results.csv (validation + test, all models),
results/task8_comparison.xlsx
"""
import argparse
import json
from pathlib import Path

import joblib
import pandas as pd

import config as C
from task7_pipeline import sha256_file
from task7_baselines import (load_derived, forecast_tasks, baseline_last_week, baseline_weekday_hour_median,
                             score, comparison_table)
from task8_model import _series_frames, build_features, baseline_persistence, predictions_frame

ML = "ML_GBM"
MODELS4 = ["B1_last_week", "B2_weekday_hour_median", "B3_persistence", ML]
ap = argparse.ArgumentParser()
ap.add_argument("--data", type=Path, default=Path(C.DERIVED_PATH))
a = ap.parse_args()

frozen = Path(C.FROZEN_CONFIG)
if not frozen.exists():
    raise SystemExit("no frozen configuration — run run_task8_tune.py first")
cfg = json.loads(frozen.read_text())
if sha256_file(a.data) != cfg["dataset"]["sha256"]:
    raise SystemExit("dataset differs from the one the model was frozen on")

h = load_derived(a.data)
S = cfg["series"]
frames = _series_frames(h)
preds = []
for hz, c in cfg["horizons"].items():
    mp = frozen.parent / c["model_file"]
    if sha256_file(mp) != c["model_sha256"]:
        raise SystemExit(f"{mp} differs from the frozen model")
    model = joblib.load(mp)
    scale = pd.Series(c["scale_Wh"])
    tt = forecast_tasks(h, hz, "test", S)
    T = build_features(h, tt, scale, frames=frames)
    preds += [predictions_frame(T, model.predict(T), ML), baseline_last_week(h, tt),
              baseline_weekday_hour_median(h, tt), baseline_persistence(h, tt, frames=frames)]
TP = pd.concat(preds, ignore_index=True).drop(columns=["input_hour"], errors="ignore")
TP.to_parquet("results/task8_test_predictions.parquet", index=False)

own = [score(TP, "energy_Wh", models=[m]).query("model == @m").assign(mask=f"own") for m in MODELS4]
test_res = pd.concat([score(TP, "energy_Wh", models=MODELS4).assign(mask="common_4"), *own], ignore_index=True)
val_res = pd.read_csv("results/task8_validation_results.csv", dtype={"dataset_version": str})
VP = pd.read_parquet("results/task8_validation_predictions.parquet")
val_own = [score(VP, "energy_Wh", models=[m]).query("model == @m").assign(mask="own") for m in MODELS4]
val_res = pd.concat([val_res[val_res["mask"] == "common_4"], *val_own], ignore_index=True)
allres = pd.concat([val_res, test_res], ignore_index=True)
allres.to_csv("results/task8_results.csv", index=False)

common = allres[allres["mask"] == "common_4"]
comp = comparison_table(common)
for b in MODELS4[:3]:
    comp[f"ML_vs_{b.split('_')[0]}_MAE_change"] = comp[f"MAE_{ML}"] / comp[f"MAE_{b}"] - 1
summary = (common.groupby(["split", "horizon", "model"])
                 .agg(median_MAE_rel=("MAE_rel", "median"), hours_scored=("n_valid", "sum")).reset_index())
wins = comp.groupby(["split", "horizon"])["best_by_MAE"].value_counts().unstack(fill_value=0).reset_index()
cov = allres[allres["mask"] == "own"].pivot_table(index=["split", "horizon"], columns="model", values="coverage",
                                                    aggfunc="mean").reset_index()
with pd.ExcelWriter("results/task8_comparison.xlsx") as xw:
    summary.to_excel(xw, sheet_name="summary", index=False)
    wins.to_excel(xw, sheet_name="wins_by_MAE", index=False)
    comp.to_excel(xw, sheet_name="comparison_by_series", index=False)
    cov.to_excel(xw, sheet_name="coverage_own", index=False)
    allres.to_excel(xw, sheet_name="results_long", index=False)
    pd.read_csv("results/task8_tuning_log.csv").to_excel(xw, sheet_name="tuning_log", index=False)
    pd.DataFrame([{"horizon": k, **{kk: (json.dumps(vv) if isinstance(vv, dict) else vv) for kk, vv in v.items()}}
                  for k, v in cfg["horizons"].items()]).to_excel(xw, sheet_name="frozen_config", index=False)
from openpyxl import load_workbook
wb = load_workbook("results/task8_comparison.xlsx")
for ws in wb.worksheets:
    ws.freeze_panes = "A2"
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = min(45, max(10, *(len(str(x.value or "")) + 2 for x in col)))
wb.save("results/task8_comparison.xlsx")

pd.set_option("display.width", 200)
print(summary.to_string(index=False)); print(wins.to_string(index=False))
print("wrote results/task8_results.csv, task8_test_predictions.parquet, task8_comparison.xlsx")
