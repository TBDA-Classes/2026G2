# %% [markdown]
# # Task 7 + 8 self-check
# Run cell by cell in VSCode ("Run Cell" above each `# %%`, or Shift+Enter), or all at once:
#     python self_check.py [--fresh <folder with a clean rebuild>]
# Every check prints PASS or FAIL. Nothing here changes any file in the project folder.

# %% 0 — setup
import hashlib, json, sys, platform
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()
sys.path.insert(0, str(ROOT))
import config as C
from task7_baselines import load_derived, forecast_tasks
from task8_model import _series_frames, build_features

FRESH = None                                     # set to a folder with a clean rebuild, e.g. Path("../task8_fresh")
if "--fresh" in sys.argv:
    FRESH = Path(sys.argv[sys.argv.index("--fresh") + 1])
cfg = json.loads((ROOT / C.FROZEN_CONFIG).read_text())
results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok)))
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  —  {detail}" if detail else ""))


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


# %% 1 — environment: same library versions as when the model was frozen
import sklearn
want = cfg["versions"]
have = dict(python=platform.python_version(), sklearn=sklearn.__version__, pandas=pd.__version__, numpy=np.__version__)
for k in want:
    check(f"version {k}", have[k] == want[k], f"have {have[k]}, frozen with {want[k]}")
print("(A different version is not an error, but exact reproduction of the numbers is only guaranteed with the same versions.)")

# %% 2 — data and model files are exactly the ones the results were produced from
frozen_csv = ROOT / "data" / "Storey1_ALL_ZONES_FROZEN_v1.0.csv.xz"
meta = json.loads((ROOT / "derived" / f"Storey1_hourly_v{C.DERIVED_VERSION}_META.json").read_text())
if frozen_csv.exists():
    check("frozen source file = file the dataset was built from", sha(frozen_csv) == meta["source_sha256_file"])
else:
    print("SKIP  frozen source file not in data/ (only needed for a full rebuild)")
check("hourly dataset v1.1 matches its META checksum", sha(ROOT / C.DERIVED_PATH) == meta["derived_sha256"])
check("hourly dataset = dataset the model was frozen on", sha(ROOT / C.DERIVED_PATH) == cfg["dataset"]["sha256"])
for hz, c in cfg["horizons"].items():
    check(f"model file {hz} unchanged since freezing", sha(ROOT / "models" / c["model_file"]) == c["model_sha256"])

# %% 3 — the dataset follows the rules (missing is never zero, splits, pre-outage hours)
h = load_derived()
check("invalid hours have no energy value (never filled with 0)", h.loc[~h.energy_valid, "energy_Wh"].isna().all())
check("pre-outage hours are invalid", (~h.loc[h.energy_pre_outage, "energy_valid"]).all(),
      f"{int(h.energy_pre_outage.sum())} flagged hours")
n = h[h.series_id == "NE|HVAC"].groupby("split").size()
check("split sizes: 816 train / 168 validation / 168 test hours per series",
      (n["train"], n["validation"], n["test"]) == (816, 168, 168), n.to_dict())

# %% 4 — recompute one forecast's inputs by hand (day-ahead, NW|Lighting, 1 Oct 09:00 Madrid)
S = cfg["series"]
scale = pd.Series(cfg["horizons"]["day-ahead"]["scale_Wh"])
t = forecast_tasks(h, "day-ahead", "test", S)
F = build_features(h, t, scale, frames=_series_frames(h))
target = pd.Timestamp("2025-10-01 09:00", tz="Europe/Madrid").tz_convert("UTC")
r = F[(F.series_id == "NW|Lighting") & (F.target_time == target)].iloc[0]
y = h[h.series_id == "NW|Lighting"].set_index("hour_utc").energy_Wh
tau, T, H = r.issue_time, r.target_time, pd.Timedelta(hours=1)
print("forecast made at", tau.tz_convert("Europe/Madrid"), "for", T.tz_convert("Europe/Madrid"))
hand = {"last_val": y[tau - H], "mean_24": y[tau - 24 * H: tau - H].mean(), "mean_168": y[tau - 168 * H: tau - H].mean(),
        "lag_T24": y[T - 24 * H], "lag_T168": y[T - 168 * H],
        "wk_median": np.nanmedian([y.get(T - k * H) for k in (168, 336, 504, 672)])}
for k, v in hand.items():
    check(f"input {k}", np.isclose(r[k] * r.scale, v), f"pipeline {r[k] * r.scale:.2f} vs hand {v:.2f}")
check("every input hour lies before the forecast time", (tau - H) < tau and (T - 24 * H) < tau)

# %% 5 — recompute baseline forecasts and one error score by hand
P = pd.read_parquet(ROOT / "results" / "task8_test_predictions.parquet")
row = P[(P.horizon == "day-ahead") & (P.series_id == "NW|Lighting") & (P.target_time == target)].set_index("model")
tr = h[(h.series_id == "NW|Lighting") & (h.split == "train")]
loc = tr.hour_local
Tl = T.tz_convert("Europe/Madrid")
b2 = tr.loc[(loc.dt.weekday == Tl.weekday()) & (loc.dt.hour == Tl.hour), "energy_Wh"].median()
check("actual value matches dataset", np.isclose(row.loc["ML_GBM", "y_true"], y[T]))
check("Baseline 1 = same hour last week", np.isclose(row.loc["B1_last_week", "y_pred"], y[T - 168 * H]))
check("Baseline 2 = median of training hours with same weekday and hour",
      np.isclose(row.loc["B2_weekday_hour_median", "y_pred"], b2))
check("Baseline 3 = last hour before the forecast time", np.isclose(row.loc["B3_persistence", "y_pred"], y[tau - H]))
model = joblib.load(ROOT / "models" / cfg["horizons"]["day-ahead"]["model_file"])
check("ML prediction reproduces from the saved model",
      np.isclose(model.predict(F[(F.series_id == "NW|Lighting") & (F.target_time == target)])[0], row.loc["ML_GBM", "y_pred"]))

g = P[(P.horizon == "+1h") & (P.series_id == "NE|Plugs & Sockets")]
w = g.pivot_table(index="target_time", columns="model", values=["y_true", "y_pred"], dropna=False)
ok = w["y_true"].notna().all(axis=1) & w["y_pred"].notna().all(axis=1)
mae_hand = np.mean(np.abs(w["y_true"]["ML_GBM"][ok] - w["y_pred"]["ML_GBM"][ok]))
res = pd.read_csv(ROOT / "results" / "task8_results.csv")
mae_file = res[(res["mask"] == "common_4") & (res.split == "test") & (res.horizon == "+1h") &
               (res.series_id == "NE|Plugs & Sockets") & (res.model == "ML_GBM")].MAE.iloc[0]
check("MAE in results table = MAE by hand (+1h, NE|Plugs & Sockets, test)", np.isclose(mae_hand, mae_file),
      f"{mae_hand:.3f} vs {mae_file:.3f}")

# %% 6 — leakage experiment: change everything from the forecast time on, inputs and forecast must not move
first = F.issue_time == F.issue_time.min()
h2 = h.copy()
h2.loc[h2.hour_utc >= F.issue_time.min(), "energy_Wh"] *= 50
F2 = build_features(h2, t, scale, frames=_series_frames(h2))
cols = [c for c in model.models["ALL"].feature_names_in_ if c != "series_code"]
check("inputs unchanged when future values change", F.loc[first, cols].equals(F2.loc[first, cols]))
check("forecasts unchanged when future values change", np.allclose(model.predict(F[first]), model.predict(F2[first])))
h3 = h.copy()
h3.loc[h3.split.isin(["validation", "test"]), "energy_Wh"] *= 50
from task8_model import series_scale
cut = pd.Timestamp(cfg["horizons"]["day-ahead"]["fit_cutoff_utc"])
check("circuit scales use training data only", series_scale(h3[h3.series_id.isin(S)], cut).round(6).equals(
    series_scale(h[h.series_id.isin(S)], cut).round(6)))

# %% 7 — optional: compare a clean rebuild in another folder with the delivered results
if FRESH is None:
    print("SKIP  no --fresh folder given (see guide, step 4)")
else:
    for f in ["results/task7_results.csv", "results/task8_tuning_log.csv", "results/task8_results.csv"]:
        check(f"rebuild identical: {f}", pd.read_csv(ROOT / f).equals(pd.read_csv(FRESH / f)))
    for f in ["derived/Storey1_hourly_v1.1.parquet", "results/task8_test_predictions.parquet"]:
        check(f"rebuild identical: {f}", pd.read_parquet(ROOT / f).equals(pd.read_parquet(FRESH / f)))
    a, b = (json.loads((p / C.FROZEN_CONFIG).read_text())["horizons"] for p in (ROOT, FRESH))
    check("rebuild chose the same model settings", {k: (v["mode"], v["params"]) for k, v in a.items()} ==
          {k: (v["mode"], v["params"]) for k, v in b.items()})

# %% 8 — summary
failed = [n for n, ok in results if not ok]
print(f"\n{len(results) - len(failed)} of {len(results)} checks passed" + (f"; FAILED: {failed}" if failed else ""))
