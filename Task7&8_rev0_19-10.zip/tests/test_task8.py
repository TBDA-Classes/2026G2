"""pytest -q tests/   — Task 8 features, persistence baseline and model on toy hourly data."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task7_pipeline import add_split_and_calendar
from task7_baselines import forecast_tasks
from task8_model import (FEATURES, build_features, baseline_persistence, series_scale, training_frame,
                         fit_cutoff, GBMForecaster)

H = pd.Timedelta(hours=1)


def toy(sids=("A", "B"), noise=0.0, seed=0):
    rng = np.random.default_rng(seed)
    hours = pd.date_range("2025-08-18 18:00", "2025-10-13 14:00", freq="h", tz="UTC")
    rows = []
    for k, s in enumerate(sids):
        base = 10.0 * (k + 1) * (1 + (hours.hour.to_numpy() >= 8) * (hours.hour.to_numpy() < 18))
        rows.append(pd.DataFrame({"series_id": s, "hour_utc": hours,
                                  "energy_Wh": base + noise * rng.standard_normal(len(hours)),
                                  "energy_valid": True}))
    return add_split_and_calendar(pd.concat(rows, ignore_index=True))


def test_features_do_not_change_when_future_values_change():
    h = toy()
    t = forecast_tasks(h, "day-ahead", "test")
    sc = series_scale(h, fit_cutoff(h, "day-ahead", ["A", "B"]))
    F1 = build_features(h, t, sc)
    tau = t["issue_time"].min()
    first = t["issue_time"] == tau
    h2 = h.copy()
    h2.loc[h2["hour_utc"] >= tau, "energy_Wh"] *= 50                       # change everything from tau on
    F2 = build_features(h2, t, sc)
    pd.testing.assert_frame_equal(F1.loc[first, FEATURES], F2.loc[first, FEATURES])


def test_scale_uses_training_hours_before_cutoff_only():
    h = toy()
    cut = fit_cutoff(h, "+6h", ["A", "B"])
    s1 = series_scale(h, cut)
    h2 = h.copy()
    h2.loc[(h2["hour_utc"] >= cut) | (h2["split"] != "train"), "energy_Wh"] = 1e6
    pd.testing.assert_series_equal(s1, series_scale(h2, cut))


def test_training_rows_end_before_first_validation_issue():
    h = toy()
    for hz in ("+1h", "+6h", "day-ahead"):
        cut = fit_cutoff(h, hz, ["A", "B"])
        F, _ = training_frame(h, hz, ["A", "B"], cut)
        assert (F["target_time"] < cut).all() and (F["split"] == "train").all()


def test_persistence_uses_last_valid_hour_and_gives_up_after_24h():
    h = toy(("A",))
    t = forecast_tasks(h, "+1h", "test", ["A"])
    tau = t["issue_time"].iloc[50]
    h.loc[h["hour_utc"] == tau - H, "energy_Wh"] = np.nan                 # last hour missing -> use the one before
    p = baseline_persistence(h, t)
    expect = h.loc[h["hour_utc"] == tau - 2 * H, "energy_Wh"].iloc[0]
    assert p.loc[p["issue_time"] == tau, "y_pred"].iloc[0] == expect
    h.loc[(h["hour_utc"] >= tau - 30 * H) & (h["hour_utc"] < tau), "energy_Wh"] = np.nan
    p = baseline_persistence(h, t)
    assert np.isnan(p.loc[p["issue_time"] == tau, "y_pred"].iloc[0])


def test_models_fit_predict_and_are_deterministic():
    h = toy(noise=1.0)
    S = ["A", "B"]
    cut = fit_cutoff(h, "+1h", S)
    F, sc = training_frame(h, "+1h", S, cut)
    V = build_features(h, forecast_tasks(h, "+1h", "validation", S), sc)
    for mode in ("pooled", "per_series"):
        p = dict(learning_rate=0.1, max_leaf_nodes=15, min_samples_leaf=20)
        a = GBMForecaster(mode, p, S).fit(F).predict(V)
        b = GBMForecaster(mode, p, S).fit(F).predict(V)
        assert np.array_equal(a, b) and np.isfinite(a).all() and (a >= 0).all()
        mae = np.mean(np.abs(a - V["y_true"]))
        assert mae < 2.0                                                    # learns the day/night pattern
