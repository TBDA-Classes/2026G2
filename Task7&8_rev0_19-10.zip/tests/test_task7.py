"""pytest -q tests/   (toy DataFrames only, no real data needed)"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task7_pipeline import (aggregate_energy_hourly, hourly_power_current, add_split_and_calendar,
                            eligibility, mae, rmse)


def toy(minutes, energy=1.0, W=60.0, sid="NE|HVAC", src="counter"):
    t = pd.Timestamp("2025-09-01 10:00", tz="UTC") + pd.to_timedelta(minutes, unit="min")
    return pd.DataFrame({"series_id": sid, "utc": t, "hour_utc": t.floor("h"),
                         "energy_Wh": energy, "energy_source": src, "W": W, "I": W / 230})


# ---------- S06
def test_energy_full_hour_is_summed():
    out = aggregate_energy_hourly(toy(range(60)), threshold=30)
    assert out.loc[0, "energy_Wh"] == 60 and out.loc[0, "energy_n_obs"] == 60 and out.loc[0, "energy_valid"]


def test_sparse_hour_is_nan_not_zero():
    df = pd.concat([toy(range(60)), toy(range(60, 70))])          # hour 2 has only 10 rows
    out = aggregate_energy_hourly(df, threshold=30)
    h2 = out.iloc[1]
    assert not h2.energy_valid and np.isnan(h2.energy_Wh) and h2.energy_n_obs == 10


def test_hour_without_rows_appears_as_nan():
    df = pd.concat([toy(range(60)), toy(range(120, 180))])        # hour 11:00 completely missing
    out = aggregate_energy_hourly(df, threshold=30)
    assert len(out) == 3
    gap = out.iloc[1]
    assert gap.energy_n_obs == 0 and np.isnan(gap.energy_Wh) and not gap.energy_valid


def test_nan_energy_rows_do_not_count_and_zero_is_kept():
    df = toy(range(60), energy=0.0)
    df.loc[:9, "energy_Wh"] = np.nan
    out = aggregate_energy_hourly(df, threshold=30)
    assert out.loc[0, "energy_n_obs"] == 50 and out.loc[0, "energy_Wh"] == 0.0   # real zero stays zero


def test_catch_up_row_after_outage_invalidates_hour():
    df = pd.concat([toy(range(60)), toy(range(200, 260))])        # 141-min outage before 13:20
    df.loc[df.index[60], "energy_Wh"] = 141.0                     # first row after the gap carries the gap
    out = aggregate_energy_hourly(df.reset_index(drop=True), threshold=30, max_gap=15)
    h13 = out[out.hour_utc.dt.hour == 13].iloc[0]
    assert h13.energy_catch_up and not h13.energy_valid and np.isnan(h13.energy_Wh)


def test_pre_outage_hour_is_invalid():
    # rows every minute 10:00-10:39, outage, next row 11:10 carries 31 min of energy -> 10:00 loses its last 21 min
    df = pd.concat([toy(range(40)), toy(range(70, 120))]).reset_index(drop=True)
    out = aggregate_energy_hourly(df, threshold=30, max_gap=15, tail_max=5).set_index("hour_utc")
    h10, h11 = out.iloc[0], out.iloc[1]
    assert h10.energy_tail_gap_min == pytest.approx(21) and h10.energy_pre_outage and not h10.energy_valid
    assert h11.energy_catch_up and not h11.energy_valid


def test_short_tail_inside_tolerance_stays_valid():
    # last row 10:57, outage, next row 11:30 -> only 3 min of hour 10 inside the gap (<= 5) -> hour 10 stays valid
    df = pd.concat([toy(range(58)), toy(range(90, 120))]).reset_index(drop=True)
    out = aggregate_energy_hourly(df, threshold=30, max_gap=15, tail_max=5)
    assert out.iloc[0].energy_valid and not out.iloc[0].energy_pre_outage


def test_dominant_source():
    df = toy(range(60)); df.loc[:39, "energy_source"] = "spread"
    assert aggregate_energy_hourly(df).loc[0, "energy_source"] == "spread"


# ---------- S07
def test_time_weighted_mean_differs_from_arithmetic():
    # 100 W held 1 min, 0 W held 30 min, last 0 W reading 1 min -> weighted 100/32 W, arithmetic 33.3 W
    df = toy([0, 1, 31], W=0.0); df.loc[0, "W"] = 100.0
    out = hourly_power_current(df, max_gap=60, min_cov=1)
    assert out.loc[0, "W_mean"] == pytest.approx(100 / 32)
    assert df.W.mean() == pytest.approx(100 / 3)


def test_gap_cap_and_validity():
    df = toy([0, 30], W=100.0)                 # 30-min gap, capped at 5 -> 5 + 1 covered minutes
    out = hourly_power_current(df, max_gap=5, min_cov=30)
    assert out.loc[0, "W_cov_min"] == pytest.approx(6) and not out.loc[0, "W_valid"] and np.isnan(out.loc[0, "W_mean"])


def test_segment_split_at_hour_boundary():
    df = toy([58, 62], W=120.0)                # reading at 10:58 holds 4 min -> 2 min in 10h, 2 min in 11h
    out = hourly_power_current(df, max_gap=5, min_cov=0).set_index("hour_utc")
    assert out["W_cov_min"].iloc[0] == pytest.approx(2) and out["W_cov_min"].iloc[1] == pytest.approx(3)


# ---------- S08 / S10
def test_splits_and_calendar():
    hours = pd.date_range("2025-08-18 18:00", "2025-10-13 14:00", freq="h", tz="UTC")
    h = pd.DataFrame({"series_id": "A", "hour_utc": hours, "energy_valid": True})
    h = add_split_and_calendar(h)
    assert (h.split == "validation").sum() == 168 and (h.split == "test").sum() == 168
    assert (h.split == "train").sum() == 34 * 24                       # 19 Aug – 21 Sep
    assert h.loc[h.hour_utc < pd.Timestamp("2025-08-19", tz="UTC"), "split"].eq("outside").all()
    assert h.loc[h.hour_utc >= pd.Timestamp("2025-10-06", tz="UTC"), "split"].eq("outside").all()
    assert h.loc[h.hour_local.dt.date.astype(str) == "2025-10-05", "is_weekend"].all()
    el = eligibility(h)
    assert el.loc[0, "eligible"]
    h.loc[h.split.eq("test") & (h.hour < 3), "energy_valid"] = False   # 21 invalid test hours -> 87.5 %
    el = eligibility(h)
    assert not el.loc[0, "eligible"] and "test" in el.loc[0, "reason"]


# ---------- S11
def test_mae_rmse_mask_nan():
    m, n = mae([1, 2, np.nan, 4], [1, 3, 5, np.nan])
    assert n == 2 and m == pytest.approx(0.5)
    r, n = rmse([0, 3], [4, 3])
    assert n == 2 and r == pytest.approx(np.sqrt(8))


def test_no_valid_pairs_raises():
    with pytest.raises(ValueError):
        mae([np.nan, 1], [2, np.nan])
