"""pytest -q tests/   — Task 7 baselines on toy hourly data (no real data needed)."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from task7_pipeline import add_split_and_calendar
from task7_baselines import (forecast_tasks, baseline_last_week, baseline_weekday_hour_median,
                             common_mask, append_results, score)


def toy_hourly(sids=("A", "B")):
    """Hourly grid over the real window; value = 100*series + hour-of-week, so lag-168 values are predictable."""
    hours = pd.date_range("2025-08-18 18:00", "2025-10-13 14:00", freq="h", tz="UTC")
    rows = []
    for k, s in enumerate(sids):
        how = (hours.dayofweek * 24 + hours.hour).to_numpy()
        rows.append(pd.DataFrame({"series_id": s, "hour_utc": hours, "energy_Wh": 100.0 * k + how,
                                  "energy_valid": True}))
    return add_split_and_calendar(pd.concat(rows, ignore_index=True))


H = pd.Timedelta(hours=1)


# ---------- S12
def test_day_ahead_issued_at_madrid_midnight_and_seven_targets_per_lead():
    h = toy_hourly(("A",))
    t = forecast_tasks(h, "day-ahead", "validation")
    loc = t["issue_time"].dt.tz_convert("Europe/Madrid")
    assert (loc.dt.hour == 0).all() and (loc.dt.minute == 0).all()
    assert t.groupby("lead").size().eq(7).all() and t["lead"].between(1, 24).all()
    assert len(t) == 168 and t["target_time"].nunique() == 168                    # every validation hour once
    assert (t["target_time"] == t["issue_time"] + (t["lead"] - 1) * H).all()


def test_hourly_horizons_cover_split_with_correct_issue_times():
    h = toy_hourly(("A",))
    for hz, L in [("+1h", 1), ("+6h", 6)]:
        t = forecast_tasks(h, hz, "test")
        assert len(t) == 168 and (t["target_time"] - t["issue_time"]).eq((L - 1) * H).all()


# ---------- S16
def test_last_week_equals_value_168h_earlier_and_missing_stays_nan():
    h = toy_hourly(("A",))
    t = forecast_tasks(h, "day-ahead", "test")
    p = baseline_last_week(h, t)
    assert np.allclose(p["y_pred"], p["y_true"])                                 # toy data repeats weekly
    target = p["target_time"].iloc[30]
    h.loc[h["hour_utc"] == target - 168 * H, "energy_Wh"] = np.nan          # hide last week's value
    p = baseline_last_week(h, t)
    assert np.isnan(p.loc[p["target_time"] == target, "y_pred"]).all()


# ---------- S17
def test_median_uses_training_only():
    h = toy_hourly(("A",))
    t = forecast_tasks(h, "day-ahead", "test")
    p1 = baseline_weekday_hour_median(h, t)
    h2 = h.copy()
    h2.loc[h2["split"].isin(["validation", "test"]), "energy_Wh"] *= 1000    # change unseen periods
    p2 = baseline_weekday_hour_median(h2, t)
    assert np.allclose(p1["y_pred"], p2["y_pred"])


def test_median_ignores_training_hours_after_first_issue_time():
    h = toy_hourly(("A",))
    t = forecast_tasks(h, "day-ahead", "validation")                              # first issue 21 Sep 22:00 UTC
    cutoff = t["issue_time"].min()
    assert cutoff == pd.Timestamp("2025-09-21 22:00", tz="UTC")
    h2 = h.copy()
    h2.loc[(h2["split"] == "train") & (h2["hour_utc"] >= cutoff), "energy_Wh"] = 1e9
    assert np.allclose(baseline_weekday_hour_median(h, t)["y_pred"], baseline_weekday_hour_median(h2, t)["y_pred"])


# ---------- scoring / S15
def test_common_mask_requires_every_model():
    h = toy_hourly(("A",))
    t = forecast_tasks(h, "day-ahead", "test")
    b1, b2 = baseline_last_week(h, t), baseline_weekday_hour_median(h, t)
    b1.loc[0, "y_pred"] = np.nan
    P = pd.concat([b1, b2], ignore_index=True)
    m = common_mask(P)
    assert (~m).sum() == 2 and m.sum() == 2 * (len(t) - 1)
    res = score(P, "energy_Wh")
    assert res["n_valid"].eq(len(t) - 1).all()


def test_append_results_replaces_same_key(tmp_path):
    h = toy_hourly(("A",))
    t = forecast_tasks(h, "+1h", "test")
    res = score(pd.concat([baseline_last_week(h, t), baseline_weekday_hour_median(h, t)]), "energy_Wh")
    f = tmp_path / "r.csv"
    append_results(res, f)
    out = append_results(res, f)
    assert len(out) == len(res)
