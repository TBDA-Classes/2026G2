"""Run S05–S10 end to end.

    python run_task7.py --data data/Storey1_ALL_ZONES_FROZEN_v1.0.csv.xz [--out derived]
"""
import argparse
from pathlib import Path

import pandas as pd

import config as C
from task7_pipeline import (load_frozen, recent_regime, aggregate_energy_hourly, hourly_power_current,
                            add_split_and_calendar, save_derived, eligibility, eligibility_to_excel, sha256_file)

ap = argparse.ArgumentParser()
ap.add_argument("--data", type=Path, required=True)
ap.add_argument("--out", type=Path, default=Path("derived"))
a = ap.parse_args()

sha_before = sha256_file(a.data)
df = load_frozen(a.data)                                                     # S05
print(f"S05 loaded {len(df):,} rows, {df.series_id.nunique()} series")
rec = recent_regime(df)
e = aggregate_energy_hourly(rec)                                             # S06
p = hourly_power_current(rec)                                                # S07
h = add_split_and_calendar(e.merge(p, on=["series_id", "hour_utc"], how="left"))  # S08
print(f"S06–S08 hourly rows {len(h):,}; energy valid {h.energy_valid.mean():.1%}; W valid {h.W_valid.mean():.1%}")
print(h.groupby("split").hour_utc.agg(["min", "max", "size"]))
pq, meta = save_derived(h, a.data, a.out)                                    # S09
print(f"S09 wrote {pq} and {meta}")

elig = eligibility(h)                                                        # S10
sens = []
for t in [20, 30, 40, 45, 50]:
    el = eligibility(add_split_and_calendar(aggregate_energy_hourly(rec, threshold=t)))
    sens.append({"THRESHOLD": t, "eligible_series": int(el.eligible.sum()), "of": len(el),
                 "excluded": ", ".join(el.loc[~el.eligible, "series_id"])})
sens = pd.DataFrame(sens)
x = eligibility_to_excel(elig, a.out / f"S10_eligibility_v{C.DERIVED_VERSION}_THRESHOLD{C.THRESHOLD}.xlsx", sens)
print(elig.to_string(index=False)); print(sens.to_string(index=False)); print(f"S10 wrote {x}")

assert sha256_file(a.data) == sha_before, "source file changed!"
print("source file unchanged (sha256 identical before and after)")
