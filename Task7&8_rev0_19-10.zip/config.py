"""Task 7 — central parameters.

Every value marked OPEN is a team decision that was not in the material I had
(S01–S04 were not part of the handover). Change it here only, never inside the
functions, so the JSON metadata of S09 always records what was used.
"""
import pandas as pd

TZ_LOCAL = "Europe/Madrid"

# Only the 2025 regime is minute-level (Task 2 cut, see load_frozen_dataset.py).
# The 2020–2023 regime is already hourly and is NOT processed by this pipeline.
REGIME_CUT_UTC = pd.Timestamp("2024-01-01", tz="UTC")

# S06 — an hour's energy is valid if it has at least THRESHOLD minute rows with energy_Wh.
# 30 = the value used in the Task 6 coverage analysis (task6_split_design.py). Observed in the data: median 48 rows/hour, max 57, never 60.
# 30 -> 86.6 % of hours valid, 45 -> 67.5 %. See S10 sensitivity sheet before deciding.
THRESHOLD = 30

# S06 — catch-up guard. After an outage, the first row's energy_Wh contains the energy of the WHOLE gap
# (e.g. 10,229 Wh after a 1,006-min outage on 2025-09-17). An hour containing a row whose preceding gap is
# longer than ENERGY_MAX_GAP minutes is marked invalid. OPEN (addition to the S06 spec, needs team OK).
ENERGY_MAX_GAP = 15
# S06 v1.1 — pre-outage guard. If more than ENERGY_TAIL_MAX minutes at the END of an hour fall inside a gap
# longer than ENERGY_MAX_GAP, that energy is booked in a later catch-up row and the hour's sum is too low ->
# invalid (energy_pre_outage). 5 min = normal spacing between readings (same as MAX_GAP). 96 hours, all in train.
ENERGY_TAIL_MAX = 5

# S07 — a W/I reading "holds" until the next reading, but at most MAX_GAP minutes.
# OPEN. 5 min covers ~98 % of the gaps between readings in 2025.
MAX_GAP = 5
# S07 — hourly W/I mean is valid if the readings cover at least this many minutes.
# OPEN. Same value as THRESHOLD so energy and power use a comparable rule.
MIN_COVERAGE_MIN = 30

# S08 — split boundaries as agreed in Task 6 (task6.pdf §4, task6_split_design.py), [start, end).
# Interpreted in UTC exactly like task6_split_design.py. 18 Aug (partial day) and everything after
# 5 Oct are "outside". Validation and test = 7 days = 168 hours each.
SPLIT_TZ = "UTC"
SPLITS = {
    "train":      ("2025-08-19 00:00", "2025-09-22 00:00"),
    "validation": ("2025-09-22 00:00", "2025-09-29 00:00"),
    "test":       ("2025-09-29 00:00", "2025-10-06 00:00"),
}
HOLIDAY_COUNTRY = "ES"
HOLIDAY_SUBDIV = "MD"

# S10
ELIGIBILITY_SHARE = 0.90
EXPECTED_HOURS = {"validation": 168, "test": 168}

DATASET_VERSION = "1.0"          # frozen input version
DERIVED_VERSION = "1.1"          # version of the derived hourly dataset (S09). 1.1 = pre-outage rule added

# ------------------------------------------------------------------ Task 7 baselines (S12–S18, S31)
# Team decisions of 18 Oct 2026:
#  - Day-ahead forecasts are issued at MIDNIGHT MADRID TIME and cover the 24 local hours of that day.
#    Split boundaries stay in UTC (Task 6). Every target hour is scored in the split its hour belongs to.
#  - Protocol §9 reworded: values observed before the issue time may be used as inputs (also from
#    validation/test); validation/test data are never used to fit or tune anything.
DERIVED_PATH = f"derived/Storey1_hourly_v{DERIVED_VERSION}.parquet"
ISSUE_TZ_DAY_AHEAD = "Europe/Madrid"
# horizon name -> leads. Lead L = the hour that starts (L-1) h after the issue time.
# Known at issue time tau: every hour that STARTS before tau (it has ended by tau).
HORIZONS = {"+1h": [1], "+6h": [6], "day-ahead": list(range(1, 25))}
BASELINE_TARGETS = ["energy_Wh"]
SEASONAL_LAG_H = 168                 # Baseline 1: same hour one week earlier
REGIME = "recent_2025"

# ------------------------------------------------------------------ Task 8 first ML model
# Decisions (18 Oct): gradient boosting only; fit on TRAINING data only, no refit on train+validation
# (protocol §4/§8/§9); configuration chosen on validation, then frozen; test used once.
PERSISTENCE_MAX_AGE_H = 24          # B3: last valid hour before the issue time, at most 24 h old
SEED = 0
GBM_FIXED = dict(loss="absolute_error", max_iter=300, early_stopping=False, l2_regularization=0.0)
GBM_GRID = [dict(learning_rate=lr, max_leaf_nodes=nl, min_samples_leaf=ms)
            for lr in (0.05, 0.1) for nl in (15, 31) for ms in (20, 50)]          # 8 configurations
MODEL_MODES = ["pooled", "per_series"]   # one model for all series vs one model per series (Task 5 §6)
# Selection metric, fixed before tuning: mean over series of (validation MAE / series training mean).
SELECTION_METRIC = "mean_scaled_MAE"
FROZEN_CONFIG = "models/task8_frozen_config.json"
