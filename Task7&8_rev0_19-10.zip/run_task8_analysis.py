"""Task 8 — error analysis of the frozen model vs the baselines (reads predictions, fits nothing on test).

    python run_task8_analysis.py

Writes results/task8_error_analysis.xlsx and results/task8_tables.md (the tables quoted in README_Task8.md).
Feature importance is computed on VALIDATION only.
"""
import json

import joblib
import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance

import config as C
from task7_baselines import load_derived, forecast_tasks
from task8_model import _series_frames, build_features

M = ["B1_last_week", "B2_weekday_hour_median", "B3_persistence", "ML_GBM"]
SHORT = {"B1_last_week": "B1", "B2_weekday_hour_median": "B2", "B3_persistence": "B3", "ML_GBM": "ML"}
KEY = ["horizon", "split", "series_id", "issue_time", "target_time", "lead"]
cfg = json.loads(open(C.FROZEN_CONFIG).read())
h = load_derived()
VP = pd.read_parquet("results/task8_validation_predictions.parquet")
TP = pd.read_parquet("results/task8_test_predictions.parquet")


def common(P):
    ok = P.assign(ok=P["y_true"].notna() & P["y_pred"].notna()).groupby(KEY)["ok"].agg(["all", "size"])
    keep = ok[ok["all"] & (ok["size"] == len(M))].index
    return P.set_index(KEY).loc[lambda d: d.index.isin(keep)].reset_index()


def event_mask(P):
    """Known test-week events: NE|HVAC real run on 3 Oct (Madrid date); NW|Emerg. Lighting hours whose energy is
    > 2x the measured power and > 20 Wh (data error). Used only for a sensitivity view, never removed from results."""
    x = h[(h.series_id == "NW|Emerg. Lighting") & h.energy_valid & h.W_valid]
    bad = set(x.loc[(x.energy_Wh / x.W_mean > 2) & (x.energy_Wh > 20), "hour_utc"])
    loc = P["target_time"].dt.tz_convert(C.TZ_LOCAL).dt.date.astype(str)
    return ((P.series_id == "NE|HVAC") & (loc == "2025-10-03")) | ((P.series_id == "NW|Emerg. Lighting") & P.target_time.isin(bad))


def overview(P, label):
    P = common(P); rows = []
    for hz, g in P.groupby("horizon", sort=False):
        sc = pd.Series(cfg["horizons"][hz]["scale_Wh"])
        mae = g.assign(ae=(g.y_true - g.y_pred).abs()).groupby(["model", "series_id"]).ae.mean().unstack()
        smae = (mae / sc).mean(axis=1)
        rows.append({"set": label, "horizon": hz, **{f"{SHORT[m]} scaled MAE": round(smae[m], 3) for m in M},
                     "best": SHORT[smae.idxmin()],
                     "ML better than B2": f"{int((mae.loc['ML_GBM'] < mae.loc['B2_weekday_hour_median']).sum())}/8",
                     "ML better than B3": f"{int((mae.loc['ML_GBM'] < mae.loc['B3_persistence']).sum())}/8",
                     "hours": len(g) // len(M)})
    return pd.DataFrame(rows)


def per_series(P, split):
    P = common(P)
    t = P.assign(ae=(P.y_true - P.y_pred).abs()).groupby(["horizon", "series_id", "model"]).ae.mean().unstack()
    return t.rename(columns=SHORT)[["B1", "B2", "B3", "ML"]].round(2).reset_index().assign(split=split)


def by_lead(P, label):
    P = common(P); P = P[P.horizon == "day-ahead"].copy()
    sc = pd.Series(cfg["horizons"]["day-ahead"]["scale_Wh"])
    P["sae"] = (P.y_true - P.y_pred).abs() / P.series_id.map(sc)
    P["hours ahead"] = pd.cut(P.lead, [0, 3, 6, 12, 18, 24], labels=["1–3", "4–6", "7–12", "13–18", "19–24"])
    out = P.groupby(["hours ahead", "model"], observed=True).sae.mean().unstack().rename(columns=SHORT)
    return out[["B1", "B2", "B3", "ML"]].round(3).reset_index().assign(set=label)


def importance():
    S = cfg["series"]; fr = _series_frames(h); out = {}
    for hz, c in cfg["horizons"].items():
        m = joblib.load("models/" + c["model_file"]); sc = pd.Series(c["scale_Wh"])
        V = build_features(h, forecast_tasks(h, hz, "validation", S), sc, frames=fr)
        V = V[V.y_scaled.notna()]
        pi = permutation_importance(m.models["ALL"], m._X(V), V.y_scaled, scoring="neg_mean_absolute_error",
                                    n_repeats=5, random_state=C.SEED)
        out[hz] = pd.Series(pi.importances_mean, index=m._X(V).columns)
    imp = pd.DataFrame(out)
    return imp.div(imp.clip(lower=0).sum()).round(3).sort_values("day-ahead", ascending=False)


ov = pd.concat([overview(VP, "validation"), overview(TP, "test"), overview(TP[~event_mask(TP)], "test without 2 events")])
ps = pd.concat([per_series(VP, "validation"), per_series(TP, "test")])
ld = pd.concat([by_lead(VP, "validation"), by_lead(TP, "test"), by_lead(TP[~event_mask(TP)], "test without 2 events")])
tl = pd.read_csv("results/task8_tuning_log.csv")
pv = tl.groupby(["horizon", "mode"])["mean_scaled_MAE"].min().unstack().round(4).reset_index()
imp = importance() if all(c["mode"] == "pooled" for c in cfg["horizons"].values()) else pd.DataFrame()

with pd.ExcelWriter("results/task8_error_analysis.xlsx") as xw:
    ov.to_excel(xw, sheet_name="overview", index=False)
    ps.to_excel(xw, sheet_name="MAE_by_series", index=False)
    ld.to_excel(xw, sheet_name="day_ahead_by_lead", index=False)
    pv.to_excel(xw, sheet_name="pooled_vs_per_series", index=False)
    imp.to_excel(xw, sheet_name="feature_importance_val")


def md(df):
    df = df.copy()
    for c in df.columns:
        if not pd.api.types.is_numeric_dtype(df[c]):
            df[c] = df[c].astype(str).str.replace("|", "\\|", regex=False)
    cols = [str(c) for c in df.columns]
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    lines += ["| " + " | ".join(str(v) for v in r) + " |" for r in df.itertuples(index=False)]
    return "\n".join(lines)


with open("results/task8_tables.md", "w") as f:
    f.write("## overview\n" + md(ov) + "\n\n## pooled_vs_per_series (best validation score)\n" + md(pv) + "\n\n")
    for sp in ["validation", "test"]:
        for hz in C.HORIZONS:
            f.write(f"## MAE {sp} {hz}\n" + md(ps[(ps.split == sp) & (ps.horizon == hz)].drop(columns=["split", "horizon"])) + "\n\n")
    f.write("## day-ahead by lead\n" + md(ld) + "\n\n## importance\n" + md(imp.reset_index().rename(columns={"index": "input"})) + "\n")
print(ov.to_string(index=False))
print("wrote results/task8_error_analysis.xlsx and results/task8_tables.md")
