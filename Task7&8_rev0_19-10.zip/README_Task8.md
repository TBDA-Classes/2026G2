# Task 8 — first ML forecasting model (gradient boosting)

```
pip install pandas pyarrow holidays openpyxl scikit-learn joblib pytest
python -m pytest -q tests/                  # 26 tests on toy data (14 dataset, 7 baselines, 5 ML model)
python self_check.py                        # 29 hand-checks (35 with --fresh <rebuilt folder>), see the self-check guide
python run_task7.py --data data/Storey1_ALL_ZONES_FROZEN_v1.0.csv.xz --out derived   # dataset v1.1
python run_task7_baselines.py               # Task 7 baselines
python run_task8_tune.py                    # train on train, choose on validation, freeze (~2.5 min)
python run_task8_test.py                    # frozen models, test week once, comparison table
python run_task8_analysis.py                # error analysis (~1 min)
```

| File | What it does |
|---|---|
| `task8_model.py` | Model inputs (`build_features`), persistence baseline B3, gradient-boosting forecaster (pooled or per series) |
| `run_task8_tune.py` | Trains every configuration on training data, scores it on validation, freezes the best one per horizon. Never builds test rows. Refuses to overwrite an existing freeze |
| `run_task8_test.py` | Loads only the frozen models (checksums checked), predicts the test week, scores all four models on the same hours |
| `run_task8_analysis.py` | Error analysis: overview, per series, by hours ahead, event sensitivity, input importance (validation only) |
| `models/` | `task8_frozen_config.json` + one fitted model per horizon |
| `results/` | `task8_results.csv` (validation + test, all models), `task8_comparison.xlsx`, `task8_error_analysis.xlsx`, predictions, tuning log |

## Setup
- **Model:** scikit-learn `HistGradientBoostingRegressor` with absolute-error loss (MAE is the primary metric). One model per horizon (+1h, +6h, day-ahead with "hours ahead" as an input).
- **Inputs, all known at the moment the forecast is made:**
  - **recent consumption:** last valid hour (max. 24 h old) and its age; mean/std of the last 24 h; mean of the last 168 h; number of valid hours in both windows
  - **the same hour 24 h and 168 h before the target**, plus the median of the same hour over the last 4 weeks
  - **calendar of the target hour (Madrid):** hour, weekday, weekend
  - **circuit** (pooled model only), and hours ahead
- **Scale:** consumption values are divided by each circuit's training mean, so one pooled model can serve a 1 Wh hand dryer and an 800 Wh socket circuit. Predictions are scaled back and cannot be negative.
- **Missing data:** missing inputs stay missing (the model handles them); hours without a valid target are never used for training or scoring.
- **Fourth reference, B3 persistence:** the last valid hour before the forecast is made, for every hour ahead.

## Protocol decisions
- **Training data only (decision 4):** every model is fitted on the training period only and is not refitted on training + validation (protocol §4: training = fitting, validation = selection; §9: fitted parameters from training data only; §8: test only after the configuration is chosen). To keep the reworded §9 rule, a horizon's model also ignores training hours after its earliest validation forecast (0, 5 and 2 hours for +1h, +6h, day-ahead). The model that was validated is exactly the model that was frozen and tested.
- **Selection rule, fixed before tuning:** for each horizon, the lowest mean over the 8 circuits of (validation MAE ÷ circuit training mean). The pooled model and the per-series models are compared on the same grid: 8 settings (learning rate 0.05/0.1 × 15/31 leaves × minimum leaf size 20/50), 300 trees, fixed seed, no built-in early stopping (it would use a random, non-chronological split).
- **Leakage checks in code:** every input hour must start before the forecast time; fitted quantities use training hours before the cut-off. Tests show that changing values from the forecast time on leaves the inputs unchanged.
- **Checked on validation, not adopted:** predicting the change from the last value instead of the value itself. Validation score: better day-ahead (0.368 vs 0.384), worse at +1h (0.261 vs 0.254), about equal at +6h (0.362 vs 0.360). Because it does not help consistently, the first model keeps one approach for all horizons; the variant is item 2 of the Sprint 3 list. This check was outside the predefined grid and is reported for transparency.

### Risks of the training-only rule
1. **Stale model:** the test week starts 8 days after the last training day; the model never learns from the validation week. Recent behaviour only reaches it through its inputs.
2. **Unlearned pattern:** NW\|HVAC was on standby throughout validation; the model only knows the running pattern from training.
3. **Less data:** only 35 days (about 710 hours per circuit); refitting would have added about 20%.
4. **Benefit:** the baselines are fitted the same way, so the comparison stays like-for-like, and the validation scores remain valid for the frozen model.

## Frozen configuration
| Horizon | Model setup | Learning rate | Leaves | Min. leaf size | Validation score | Training hours | Fitted on hours before (UTC) |
|---|---|---|---|---|---|---|---|
| +1h | pooled | 0.05 | 15 | 50 | 0.254 | 5,681 | 2025-09-22 00:00 |
| +6h | pooled | 0.05 | 15 | 20 | 0.360 | 5,641 | 2025-09-21 19:00 |
| day-ahead | pooled | 0.1 | 15 | 50 | 0.384 | 5,665 | 2025-09-21 22:00 |

**Pooled vs per series (best validation score):** the pooled model is better at every horizon, so the evidence supports one shared model at this data volume.

| horizon | per_series | pooled |
|---|---|---|
| +1h | 0.2661 | 0.2535 |
| +6h | 0.3779 | 0.3601 |
| day-ahead | 0.3864 | 0.3838 |

## Results
"Scaled MAE" = MAE ÷ circuit training mean, averaged over the 8 circuits (the selection metric; lower is better). All four models are scored on exactly the same hours. "Test without 2 events" is a **sensitivity view only**: it leaves out the real NE\|HVAC run on 3 Oct and the 18 NW\|Emerg. Lighting hours with impossible energy readings (more than twice the measured power). The official results keep them.

| set | horizon | B1 scaled MAE | B2 scaled MAE | B3 scaled MAE | ML scaled MAE | best | ML better than B2 | ML better than B3 | hours |
|---|---|---|---|---|---|---|---|---|---|
| validation | +1h | 0.578 | 0.427 | 0.29 | 0.246 | ML | 7/8 | 4/8 | 1120 |
| validation | +6h | 0.578 | 0.429 | 0.46 | 0.355 | ML | 7/8 | 5/8 | 1120 |
| validation | day-ahead | 0.578 | 0.427 | 0.367 | 0.384 | B3 | 6/8 | 5/8 | 1120 |
| test | +1h | 1.266 | 1.166 | 0.93 | 1.032 | B3 | 7/8 | 4/8 | 1336 |
| test | +6h | 1.267 | 1.167 | 1.887 | 1.175 | B2 | 4/8 | 8/8 | 1336 |
| test | day-ahead | 1.267 | 1.166 | 1.162 | 1.173 | B3 | 5/8 | 3/8 | 1336 |
| test without 2 events | +1h | 0.49 | 0.389 | 0.336 | 0.265 | ML | 7/8 | 6/8 | 1295 |
| test without 2 events | +6h | 0.491 | 0.39 | 0.698 | 0.398 | B2 | 4/8 | 7/8 | 1295 |
| test without 2 events | day-ahead | 0.491 | 0.389 | 0.401 | 0.395 | B2 | 5/8 | 3/8 | 1295 |

**Test MAE per circuit (Wh per hour, all hours):**

+1h
| series_id | B1 | B2 | B3 | ML |
|---|---|---|---|---|
| NE\|HVAC | 10.44 | 10.39 | 8.8 | 10.29 |
| NE\|Plugs & Sockets | 5.65 | 3.93 | 4.69 | 2.84 |
| NW\|Emerg. Lighting | 29.3 | 29.72 | 26.46 | 28.59 |
| NW\|HVAC | 37.69 | 43.86 | 15.81 | 14.19 |
| NW\|Hand Dryer | 1.15 | 0.77 | 0.56 | 0.52 |
| NW\|Lighting | 61.81 | 49.02 | 30.12 | 34.67 |
| NW\|Plugs & Sockets | 355.93 | 265.15 | 183.61 | 209.69 |
| NW\|RACK | 3.72 | 3.3 | 4.41 | 3.85 |

+6h
| series_id | B1 | B2 | B3 | ML |
|---|---|---|---|---|
| NE\|HVAC | 10.44 | 10.39 | 20.19 | 10.38 |
| NE\|Plugs & Sockets | 5.65 | 3.93 | 3.9 | 3.71 |
| NW\|Emerg. Lighting | 29.3 | 29.72 | 34.39 | 29.36 |
| NW\|HVAC | 37.69 | 43.86 | 69.31 | 50.42 |
| NW\|Hand Dryer | 1.15 | 0.77 | 0.97 | 0.79 |
| NW\|Lighting | 61.81 | 49.02 | 89.48 | 50.27 |
| NW\|Plugs & Sockets | 355.93 | 265.15 | 441.31 | 266.82 |
| NW\|RACK | 3.72 | 3.3 | 3.29 | 2.79 |

Day-ahead
| series_id | B1 | B2 | B3 | ML |
|---|---|---|---|---|
| NE\|HVAC | 10.44 | 10.39 | 10.28 | 10.36 |
| NE\|Plugs & Sockets | 5.65 | 3.93 | 4.31 | 4.66 |
| NW\|Emerg. Lighting | 29.3 | 29.72 | 27.6 | 29.59 |
| NW\|HVAC | 37.69 | 43.86 | 37.88 | 44.44 |
| NW\|Hand Dryer | 1.15 | 0.77 | 0.82 | 0.73 |
| NW\|Lighting | 61.81 | 49.02 | 52.53 | 54.74 |
| NW\|Plugs & Sockets | 355.93 | 265.15 | 322.12 | 258.65 |
| NW\|RACK | 3.72 | 3.3 | 3.51 | 2.68 |

**Day-ahead error by hours ahead (scaled MAE, test without 2 events):**
| hours ahead | B1 | B2 | B3 | ML | |
|---|---|---|---|---|
| 1–3 | 0.463 | 0.342 | 0.329 | 0.321 |
| 4–6 | 0.472 | 0.358 | 0.411 | 0.348 |
| 7–12 | 0.565 | 0.486 | 0.45 | 0.475 |
| 13–18 | 0.513 | 0.437 | 0.451 | 0.426 |
| 19–24 | 0.457 | 0.312 | 0.368 | 0.375 |

**What the model relies on** (permutation importance on validation, share of the total; top 6):
| input | +1h | +6h | day-ahead |
|---|---|---|---|
| lag_T24 | 0.118 | 0.616 | 0.554 |
| series_code | 0.095 | 0.232 | 0.197 |
| last_val | 0.755 | 0.115 | 0.109 |
| std_24 | 0.002 | 0.007 | 0.042 |
| lag_T168 | 0.011 | 0.013 | 0.037 |
| wk_median | 0.006 | -0.004 | 0.025 |

## Interpretation
**1-hour-ahead: the ML model adds clear value.** It is the best model on validation and, without the two events, on test. Its scaled MAE is 0.265 vs 0.336 for persistence and 0.389 for the weekday-hour median (21% and 32% lower). It beats the Task 7 baselines on 7 of 8 circuits in both weeks. Including the events, persistence is ahead on scaled MAE (0.930 vs 1.032), because it follows sudden jumps one hour later. Persistence also stays better on the two largest circuits in the test week (NW\|Plugs & Sockets 183.6 vs 209.7 Wh, NW\|Lighting 30.1 vs 34.7 Wh).

**6 hours and day-ahead: no measurable gain yet.** The ML model is level with the weekday-hour median: scaled MAE 0.398 vs 0.390 (+6h) and 0.395 vs 0.389 (day-ahead) without the events. It beats it on only 4 and 5 of 8 circuits. The validation advantage at +6h (0.355 vs 0.429) did not carry over to the test week. Persistence is poor at +6h (0.698) but competitive day-ahead (0.401). Day-ahead forecasts start at midnight, so hours ahead equal the time of day. In the test week without the events, the ML model is best for 00:00–06:00 and 12:00–18:00; persistence is best for 06:00–12:00, and the weekday-hour median for 18:00–24:00.

**Why.** At +6h and day-ahead the model mainly uses the same hour yesterday (55–62% of importance) and which circuit it is; calendar inputs are hardly used. With 35 days of training, each weekday appears only 5 times, so the model effectively learns "tomorrow looks like today, at this circuit's level". It cannot anticipate changes in operation such as NW\|HVAC going on standby (validation) or back into operation (1 Oct, test), and nothing in the data announces them.

**Validation vs test.** Every model, including the baselines, has 2–4× higher scaled errors in the test week, driven mostly by the two events. Without them, the ML model stays best at +1h; at +6h and day-ahead the weekday-hour median catches up, unlike in validation.

**For the Sprint Review:** the first ML model produces valid forecasts on unseen data and is quantitatively compared with three baselines. It is a clear improvement for the next hour; for 6–24 hours it matches but does not yet beat the best simple rule. That is the starting point for Sprint 3.

## Limitations
- One test week; a single event can change the ranking. No significance test is meaningful on 7 days.
- Short training history (35 days); weekly patterns are barely learnable.
- SE and SW are excluded (S10); W and I were not modelled.
- The validation week is atypical (NW\|HVAC on standby), so the chosen settings may not be ideal for normal weeks.

## Sprint 3 improvement list (priority order)
1. **More history:** use the weeks after 5 Oct with rolling evaluation and periodic refits (needs a protocol amendment). This is the main lever for weekly and calendar patterns.
2. **Day-ahead model that builds on simple rules:** predict the change from the last value (better day-ahead on validation, see above) or the deviation from the weekday-hour profile (fitted out-of-fold), and choose per horizon on validation.
3. **Operating-state and context inputs:** on/off detection for HVAC, and indoor temperature where the sensors are validated (not available for NE).
4. **Data quality rule:** flag hours where energy is far above power (NW\|Emerg. Lighting) by rule in dataset v1.2; investigate SE/SW with the data owner.
5. **Pre-trained comparison:** Chronos-Bolt zero-shot as an extra reference for short data.
6. **Ranges instead of single values:** quantile forecasts, to support anomaly detection (the project's second goal).
7. **W as second target,** only for circuits where energy and power agree.
