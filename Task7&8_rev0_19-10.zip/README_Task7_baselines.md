# Task 7 — baseline forecasts (S12–S18, S31) on dataset v1.1

```
pip install pandas pyarrow holidays openpyxl pytest
python -m pytest -q tests/                 # 26 tests (14 dataset, 7 baseline, 5 ML model), toy data only
python run_task7.py --data data/Storey1_ALL_ZONES_FROZEN_v1.0.csv.xz --out derived   # dataset v1.1 (~25 s)
python run_task7_baselines.py              # reads derived/Storey1_hourly_v1.1.parquet, writes results/
```
The baseline run reads the S09 dataset (checked against its SHA-256 in `_META.json`) and the S10 eligibility file of the same version. Running twice gives identical results; rerunning into the same folder replaces rows instead of duplicating them.

| Step | Function | What it does |
|---|---|---|
| S12 | `forecast_tasks` | All forecasts per horizon and split: `+1h` and `+6h` issued every hour; `day-ahead` issued at 00:00 Madrid, leads 1–24 |
| S16 | `baseline_last_week` | Baseline 1: value of the same hour 168 h earlier; stays NaN if that hour is missing |
| S17 | `baseline_weekday_hour_median` | Baseline 2: median of training values with the same Madrid weekday and hour |
| S15 | `score`, `append_results`, `comparison_table` | MAE/RMSE on the common mask, shared `results/task7_results.csv` |
| S18 / S31 | `run_task7_baselines.py` | Runs both baselines on validation and test for `energy_Wh`, 8 eligible series |

Outputs in `results/`: `task7_predictions_v1.1.parquet` (16,128 forecast rows), `task7_results.csv` (96 rows), `task7_comparison.xlsx` (summary, wins, per-series comparison, forecast timing, settings).

## Dataset v1.1 (pre-outage fix)
v1.0 marked the hour *after* an outage invalid (its first row carries the energy of the whole gap), but not the hour *before* it, whose last minutes are booked in that later row. v1.1 adds `energy_tail_gap_min` and `energy_pre_outage`: an hour is invalid if more than `ENERGY_TAIL_MAX` = 5 minutes at its end fall inside a gap longer than `ENERGY_MAX_GAP` = 15 minutes. 5 minutes is the normal spacing between readings.
- Effect: 96 hours change from valid to invalid, **all in training**. Nothing else in the dataset changes, and S10 eligibility is identical.
- v1.0 was first rebuilt from the frozen file and matched the existing v1.0 exactly, so the pipeline is reproducible.
- Checked on the minute data: after a row without an energy value, the next value covers only the time since that row. Measuring gaps to the previous row of any kind (as S06 does) is therefore correct.

## Decisions (18 Oct)
- **Day-ahead forecasts start at midnight Madrid time** and cover the 24 local hours of that day. Split boundaries stay in UTC (Task 6), and each target hour is scored in the split its hour belongs to. Result: every lead 1–24 has exactly 7 targets per split, and every hour of each week is scored once. The first validation forecast is issued on 21 Sep 22:00 UTC (22 Sep 00:00 Madrid), and its first two target hours belong to train, so they are not scored.
- **Protocol §9, reworded** (replace the current text):
  > Inputs to a forecast may only use observations from hours that ended before the forecast issue time. This includes observations from the validation and test periods. Validation and test data must never be used to fit, tune or select a model or to compute any fitted quantity (e.g. medians, scalers, model parameters). Fitted quantities use training data observed before the earliest issue time being evaluated.
- Both rules are enforced in code: Baseline 1 asserts its input hour lies before the issue time; Baseline 2 is fitted only on training hours before the first issue time (for validation this drops up to the last 5 training hours, depending on the horizon; see the `forecast_timing` sheet). Tests check that changing validation/test values does not change Baseline 2.

## Settings carried over
- Target `energy_Wh` (primary). W and I are not part of this run.
- Series: the 8 S10-eligible series (all NE and NW).
- Scored hours: hours where the actual value **and both** baselines exist (protocol §8, common mask). Task 8 must re-score with its model included: `score(preds, "energy_Wh", models=[...all three...])`.

## Results (energy_Wh, MAE in Wh per hour; better baseline in bold)
| Series | Avg. Wh/h (val) | B1 val | B2 val | Avg. Wh/h (test) | B1 test | B2 test |
|---|---:|---:|---:|---:|---:|---:|
| NE\|HVAC | 2.7 | 0.72 | **0.55** | 12.5 | 10.44 | **10.39** |
| NE\|Plugs & Sockets | 186.4 | 7.84 | **6.62** | 189.6 | 5.65 | **3.93** |
| NW\|Emerg. Lighting | 10.9 | 1.04 | **0.97** | 39.6 | **29.30** | 29.72 |
| NW\|HVAC | 33.7 | 137.54 | **77.47** | 70.7 | **37.69** | 43.86 |
| NW\|Hand Dryer | 0.8 | 1.16 | **1.00** | 0.6 | 1.15 | **0.77** |
| NW\|Lighting | 63.4 | 55.43 | **35.58** | 83.7 | 61.81 | **49.02** |
| NW\|Plugs & Sockets | 805.9 | 324.76 | **307.96** | 763.3 | 355.93 | **265.15** |
| NW\|RACK | 186.5 | 4.97 | **3.73** | 187.1 | 3.72 | **3.30** |

Hours scored: 1,120 in validation, 1,336 in test (8 series). Full MAE/RMSE per horizon in `task7_comparison.xlsx`.

## Interpretation
**Baseline 2 (weekday-hour median) is the stronger reference.** It has the lower MAE for all 8 series in validation and 6 of 8 in test, and it can always produce a forecast. Baseline 1 can only forecast 84% of validation hours, because the 17 Sep outage falls in the last training week; in test it covers 99%. Task 8 should therefore be judged mainly against Baseline 2, with Baseline 1 reported alongside.

**The horizon makes no difference for these baselines.** Neither uses information that becomes available closer to the target hour, so their errors are the same for +1h, +6h and day-ahead (Baseline 2 differs only marginally in validation because of the fit cut-off). This is where an ML model with recent lags should gain most: at +1h and +6h it knows what happened an hour or a few hours earlier, which these baselines ignore.

**How hard a series is depends on its load type.**
- Stable loads are easy: NW|RACK and NE|Plugs & Sockets have errors of 2–4% of their average consumption.
- Plugs and lighting with daily routines are moderate: about 35–88% of average consumption.
- NW|Hand Dryer is tiny and intermittent (under 1 Wh per hour on average). Its errors exceed its average consumption, so it says little about forecasting quality.

**The biggest errors come from changes in operation, which a weekly pattern cannot anticipate.**
- **NW|HVAC was effectively off throughout the validation week** (a flat ~34 Wh/h). In training it was running, so both baselines forecast activity that did not happen (MAE 77–138 Wh, 2–4× its average). It switched back on from 1 Oct in the test week.
- **NE|HVAC ran for about three hours on 3 Oct** (~690 Wh/h against a normal ~3). The power readings confirm this was a real event. It raises the test MAE from about 0.6 to 10.4 Wh. This is exactly the kind of unusual consumption the project aims to detect, and no baseline can predict it.
- **NW|Emerg. Lighting has 18 test hours on 5–6 Oct with energy readings 10–45× higher than the measured power.** This is a data error, not consumption. Without those hours its test MAE would be 0.93 Wh (Baseline 1) and 1.28 Wh (Baseline 2) instead of about 29.5. The hours are kept in the official results (no silent cleaning) and should be raised with the data owner.

**Validation and test errors are not comparable one-to-one.** The test week contains the events above, so higher test errors for NE|HVAC and NW|Emerg. Lighting reflect the data rather than overfitting. Baselines are not tuned, so there is nothing to overfit.

## Limitations
- 34 training days give only 2–5 values per weekday-hour slot, so Baseline 2's profile is noisy.
- SE and SW are excluded (S10). Beyond missing hours, their energy readings do not match their power readings, so they should not be added back without a data check.
- No holidays fall in train, validation or test, so the baselines are not tested on holiday behaviour.
