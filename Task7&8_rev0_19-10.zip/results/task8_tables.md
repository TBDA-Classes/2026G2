## overview
| set | horizon | B1 scaled MAE | B2 scaled MAE | B3 scaled MAE | ML scaled MAE | best | ML better than B2 | ML better than B3 | hours |
|---|---|---|---|---|---|---|---|---|---|
| validation | +1h | 0.578 | 0.427 | 0.29 | 0.246 | ML | 7/8 | 4/8 | 1120 |
| validation | +6h | 0.578 | 0.429 | 0.46 | 0.355 | ML | 7/8 | 5/8 | 1120 |
| validation | day-ahead | 0.578 | 0.427 | 0.367 | 0.384 | B3 | 6/8 | 5/8 | 1120 |
| test | +1h | 1.266 | 1.166 | 0.93 | 1.032 | B3 | 7/8 | 4/8 | 1336 |
| test | +6h | 1.267 | 1.167 | 1.887 | 1.175 | B2 | 4/8 | 8/8 | 1336 |
| test | day-ahead | 1.267 | 1.166 | 1.162 | 1.173 | B3 | 5/8 | 3/8 | 1336 |
| test without 2 events | +1h | 0.49 | 0.389 | 0.336 | 0.265 | ML | 7/8 | 6/8 | 1295 |
| test without 2 events | +6h | 0.491 | 0.39 | 0.698 | 0.398 | B2 | 4/8 | 7/8 | 1295 |
| test without 2 events | day-ahead | 0.491 | 0.389 | 0.401 | 0.395 | B2 | 5/8 | 3/8 | 1295 |

## pooled_vs_per_series (best validation score)
| horizon | per_series | pooled |
|---|---|---|
| +1h | 0.2661 | 0.2535 |
| +6h | 0.3779 | 0.3601 |
| day-ahead | 0.3864 | 0.3838 |

## MAE validation +1h
| series_id | B1 | B2 | B3 | ML |
|---|---|---|---|---|
| NE\|HVAC | 0.72 | 0.56 | 0.61 | 0.5 |
| NE\|Plugs & Sockets | 7.84 | 6.62 | 6.46 | 7.52 |
| NW\|Emerg. Lighting | 1.04 | 0.97 | 0.66 | 0.68 |
| NW\|HVAC | 137.54 | 77.2 | 1.38 | 1.82 |
| NW\|Hand Dryer | 1.16 | 1.0 | 0.89 | 0.71 |
| NW\|Lighting | 55.43 | 35.56 | 27.0 | 20.05 |
| NW\|Plugs & Sockets | 324.76 | 307.69 | 208.32 | 232.61 |
| NW\|RACK | 4.97 | 3.71 | 5.43 | 2.41 |

## MAE validation +6h
| series_id | B1 | B2 | B3 | ML |
|---|---|---|---|---|
| NE\|HVAC | 0.72 | 0.56 | 0.51 | 0.49 |
| NE\|Plugs & Sockets | 7.84 | 6.6 | 6.03 | 6.64 |
| NW\|Emerg. Lighting | 1.04 | 0.97 | 0.72 | 0.81 |
| NW\|HVAC | 137.54 | 78.26 | 2.69 | 33.1 |
| NW\|Hand Dryer | 1.16 | 1.0 | 1.22 | 0.88 |
| NW\|Lighting | 55.43 | 35.58 | 52.83 | 34.8 |
| NW\|Plugs & Sockets | 324.76 | 308.37 | 466.43 | 292.3 |
| NW\|RACK | 4.97 | 3.75 | 4.17 | 3.18 |

## MAE validation day-ahead
| series_id | B1 | B2 | B3 | ML |
|---|---|---|---|---|
| NE\|HVAC | 0.72 | 0.55 | 0.6 | 0.48 |
| NE\|Plugs & Sockets | 7.84 | 6.62 | 5.83 | 6.72 |
| NW\|Emerg. Lighting | 1.04 | 0.97 | 0.56 | 0.86 |
| NW\|HVAC | 137.54 | 77.47 | 0.98 | 65.63 |
| NW\|Hand Dryer | 1.16 | 1.0 | 0.92 | 0.85 |
| NW\|Lighting | 55.43 | 35.58 | 38.43 | 36.47 |
| NW\|Plugs & Sockets | 324.76 | 307.96 | 414.09 | 272.13 |
| NW\|RACK | 4.97 | 3.73 | 4.29 | 3.16 |

## MAE test +1h
| series_id | B1 | B2 | B3 | ML |
|---|---|---|---|---|
| NE\|HVAC | 10.44 | 10.39 | 8.8 | 10.29 |
| NE\|Plugs & Sockets | 5.65 | 3.93 | 4.69 | 2.84 |
| NW\|Emerg. Lighting | 29.3 | 29.72 | 26.46 | 28.59 |
| NW\|HVAC | 37.69 | 43.86 | 15.81 | 14.19 |
| NW\|Hand Dryer | 1.15 | 0.77 | 0.56 | 0.52 |
| NW\|Lighting | 61.81 | 49.02 | 30.12 | 34.67 |
| NW\|Plugs & Sockets | 355.93 | 265.15 | 183.61 | 209.69 |
| NW\|RACK | 3.72 | 3.3 | 4.41 | 3.85 |

## MAE test +6h
| series_id | B1 | B2 | B3 | ML |
|---|---|---|---|---|
| NE\|HVAC | 10.44 | 10.39 | 20.19 | 10.38 |
| NE\|Plugs & Sockets | 5.65 | 3.93 | 3.9 | 3.71 |
| NW\|Emerg. Lighting | 29.3 | 29.72 | 34.39 | 29.36 |
| NW\|HVAC | 37.69 | 43.86 | 69.31 | 50.42 |
| NW\|Hand Dryer | 1.15 | 0.77 | 0.97 | 0.79 |
| NW\|Lighting | 61.81 | 49.02 | 89.48 | 50.27 |
| NW\|Plugs & Sockets | 355.93 | 265.15 | 441.31 | 266.82 |
| NW\|RACK | 3.72 | 3.3 | 3.29 | 2.79 |

## MAE test day-ahead
| series_id | B1 | B2 | B3 | ML |
|---|---|---|---|---|
| NE\|HVAC | 10.44 | 10.39 | 10.28 | 10.36 |
| NE\|Plugs & Sockets | 5.65 | 3.93 | 4.31 | 4.66 |
| NW\|Emerg. Lighting | 29.3 | 29.72 | 27.6 | 29.59 |
| NW\|HVAC | 37.69 | 43.86 | 37.88 | 44.44 |
| NW\|Hand Dryer | 1.15 | 0.77 | 0.82 | 0.73 |
| NW\|Lighting | 61.81 | 49.02 | 52.53 | 54.74 |
| NW\|Plugs & Sockets | 355.93 | 265.15 | 322.12 | 258.65 |
| NW\|RACK | 3.72 | 3.3 | 3.51 | 2.68 |

## day-ahead by lead
| hours ahead | B1 | B2 | B3 | ML | set |
|---|---|---|---|---|---|
| 1–3 | 0.539 | 0.366 | 0.299 | 0.334 | validation |
| 4–6 | 0.538 | 0.336 | 0.357 | 0.285 | validation |
| 7–12 | 0.557 | 0.327 | 0.319 | 0.336 | validation |
| 13–18 | 0.646 | 0.516 | 0.442 | 0.448 | validation |
| 19–24 | 0.575 | 0.515 | 0.382 | 0.443 | validation |
| 1–3 | 0.842 | 0.721 | 0.595 | 0.702 | test |
| 4–6 | 0.562 | 0.446 | 0.495 | 0.437 | test |
| 7–12 | 1.853 | 1.782 | 1.739 | 1.769 | test |
| 13–18 | 1.835 | 1.762 | 1.773 | 1.751 | test |
| 19–24 | 0.667 | 0.527 | 0.575 | 0.59 | test |
| 1–3 | 0.463 | 0.342 | 0.329 | 0.321 | test without 2 events |
| 4–6 | 0.472 | 0.358 | 0.411 | 0.348 | test without 2 events |
| 7–12 | 0.565 | 0.486 | 0.45 | 0.475 | test without 2 events |
| 13–18 | 0.513 | 0.437 | 0.451 | 0.426 | test without 2 events |
| 19–24 | 0.457 | 0.312 | 0.368 | 0.375 | test without 2 events |

## importance
| input | +1h | +6h | day-ahead |
|---|---|---|---|
| lag_T24 | 0.118 | 0.616 | 0.554 |
| series_code | 0.095 | 0.232 | 0.197 |
| last_val | 0.755 | 0.115 | 0.109 |
| std_24 | 0.002 | 0.007 | 0.042 |
| lag_T168 | 0.011 | 0.013 | 0.037 |
| wk_median | 0.006 | -0.004 | 0.025 |
| mean_168 | 0.001 | -0.013 | 0.024 |
| hour | 0.006 | 0.014 | 0.006 |
| weekday | -0.001 | -0.006 | 0.004 |
| mean_24 | 0.005 | -0.01 | 0.001 |
| last_age_h | -0.0 | -0.0 | 0.0 |
| n_24 | -0.0 | 0.002 | -0.0 |
| is_weekend | 0.0 | 0.0 | 0.0 |
| lead | 0.0 | 0.0 | 0.0 |
| n_weeks | -0.0 | -0.003 | -0.012 |
| n_168 | 0.0 | -0.005 | -0.015 |
