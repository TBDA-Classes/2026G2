"""CeDInt Storey 1 — Sprint 2 Task 2 full temporal QA.
Run: python task2_temporal_qa.py Storey1_ALL_ZONES_MERGED2.csv
Requires: pandas. Input stays unchanged; reports written to results/.
"""
import argparse
from pathlib import Path
import pandas as pd

CUT = pd.Timestamp('2024-01-01', tz='UTC')
LABELS = {'historical': 'Historical (2020–2023)', 'recent': 'Recent (2025)'}
EXPECTED = {LABELS['historical']: 60, LABELS['recent']: 1}

def run(input_file: Path, outdir: Path):
    if not input_file.is_file():
        raise FileNotFoundError(f'Merged CSV not found: {input_file}')
    df = pd.read_csv(input_file, usecols=['zone', 'sensor', 'Timestamp', 'timestamp_madrid'], dtype='string', low_memory=False)
    df['utc'] = pd.to_datetime(df['Timestamp'], errors='coerce', utc=True)
    df['local'] = pd.to_datetime(df['timestamp_madrid'], errors='coerce')
    bad_keys = df['zone'].isna() | df['sensor'].isna() | df['zone'].str.strip().eq('') | df['sensor'].str.strip().eq('')
    bad_utc = df['utc'].isna()
    bad_local = df['local'].isna()
    if bad_keys.any() or bad_utc.any() or bad_local.any():
        raise ValueError(f'Invalid input: bad keys={bad_keys.sum()}, UTC={bad_utc.sum()}, Madrid={bad_local.sum()}')
    expected_local = df['utc'].dt.tz_convert('Europe/Madrid').dt.tz_localize(None)
    mismatches = expected_local.ne(df['local'])
    if mismatches.any():
        raise ValueError(f'UTC to Madrid conversion mismatches: {int(mismatches.sum())}')
    df['period'] = df['utc'].lt(CUT).map({True:LABELS['historical'], False:LABELS['recent']})
    unknown_years = df['utc'].dt.year[~df['utc'].dt.year.isin([2020,2021,2022,2023,2025])]
    if len(unknown_years):
        raise ValueError('Unexpected years in input: revise dataset-specific period split')
    outdir.mkdir(parents=True,exist_ok=True)

    # Step 4: UTC duplicates and Madrid wall-clock repeats, across complete series.
    utc_dup = df.duplicated(['zone','sensor','utc'],keep=False)
    local_dup = df.duplicated(['zone','sensor','local'],keep=False)
    dup_rows=[]
    for (zone,sensor),g in df.groupby(['zone','sensor'],sort=True):
        idx=g.index
        dup_rows.append(dict(zone=zone,sensor=sensor,rows=len(g),missing_zone_or_sensor=0,
            invalid_utc=0,invalid_madrid=0,utc_duplicate_rows=int(utc_dup.loc[idx].sum()),
            utc_duplicate_excess=int(g.duplicated(['utc']).sum()),
            local_repeated_rows=int(local_dup.loc[idx].sum()),
            local_repeated_excess=int(g.duplicated(['local']).sum()),madrid_conversion_mismatches=0))
    dup_df=pd.DataFrame(dup_rows)
    local_repeat=df.loc[local_dup,['zone','sensor','Timestamp','timestamp_madrid']].copy()
    local_repeat.insert(2,'utc_offset_hours', [float(t.utcoffset().total_seconds()/3600) for t in df.loc[local_dup,'utc'].dt.tz_convert('Europe/Madrid')])
    local_repeat=local_repeat.sort_values(['zone','sensor','timestamp_madrid','Timestamp'])

    # Steps 2 and 3: within-period frequencies and gap intervals.
    freq=[];gap_summary=[];gap_parts=[];bridges=[]
    for (zone,sensor),entire in df.groupby(['zone','sensor'],sort=True):
        entire=entire.sort_values('utc')
        old=entire.loc[entire.utc<CUT,'utc'];new=entire.loc[entire.utc>=CUT,'utc']
        if len(old) and len(new):
            last_old=old.iloc[-1];first_new=new.iloc[0]
            bridges.append(dict(zone=zone,sensor=sensor,historical_last_utc=last_old,recent_first_utc=first_new,
                between_regimes_hours=round((first_new-last_old).total_seconds()/3600,3),
                between_regimes_days=round((first_new-last_old).total_seconds()/86400,3),
                note='Sampling regime changes; no missing-record estimate across this interval'))
        else:
            bridges.append(dict(zone=zone,sensor=sensor,historical_last_utc=old.iloc[-1] if len(old) else pd.NaT,
                recent_first_utc=new.iloc[0] if len(new) else pd.NaT,between_regimes_hours=None,
                between_regimes_days=None,note='No observations in one regime; cross-regime gap cannot be calculated'))
        for period,g in entire.groupby('period',sort=True):
            t=g['utc'].sort_values().reset_index(drop=True)
            intervals=t.diff().dt.total_seconds().div(60)
            valid=intervals.dropna();positive=valid[valid>0];counts=positive.value_counts()
            freq.append(dict(zone=zone,sensor=sensor,period=period,observations=len(t),
                first_utc=t.min().strftime('%Y-%m-%d %H:%M'),last_utc=t.max().strftime('%Y-%m-%d %H:%M'),
                modal_interval_min=float(counts.index[0]) if len(counts) else None,
                modal_share_pct=round(100*counts.iloc[0]/len(valid),2) if len(valid) else None,
                one_min_intervals=int((valid==1).sum()),sixty_min_intervals=int((valid==60).sum()),
                other_positive_intervals=int(((valid>0)&~valid.isin([1,60])).sum()),
                zero_min_intervals=int((valid==0).sum()),
                max_gap_hours=round(valid.max()/60,2) if len(valid) else None,intervals=len(valid)))
            step=EXPECTED[period]; mask=intervals>step; idx=mask[mask].index; durations=intervals.loc[idx]
            missing=(durations/step).apply(lambda v:max(int(v)-1,0)).astype('int64')
            if len(idx):
                part=pd.DataFrame(dict(zone=zone,sensor=sensor,period=period,
                    previous_observation_utc=t.iloc[idx-1].to_numpy(),next_observation_utc=t.iloc[idx].to_numpy(),
                    interval_minutes=durations.round(6).to_numpy(),expected_interval_minutes=step,
                    excess_minutes=(durations-step).round(6).to_numpy(),
                    estimated_missing_observations=missing.to_numpy(),
                    exact_cadence_multiple=((durations/step-(durations/step).round()).abs()<1e-9).to_numpy(),
                    gap_class=['over_24h' if d>1440 else 'over_1h_to_24h' if d>60 else 'up_to_1h' for d in durations]))
                gap_parts.append(part)
            gap_summary.append(dict(zone=zone,sensor=sensor,period=period,first_utc=t.iloc[0],last_utc=t.iloc[-1],
                observations=len(t),expected_interval_minutes=step,intervals_analyzed=len(valid),
                gap_intervals=len(idx),share_gap_intervals_pct=round(100*len(idx)/max(len(t)-1,1),3),
                estimated_missing_observations=int(missing.sum()),
                max_gap_minutes=round(float(durations.max()),3) if len(idx) else 0,
                median_gap_minutes=round(float(durations.median()),3) if len(idx) else 0,
                gap_intervals_over_1h=int((durations>60).sum()),gap_intervals_over_24h=int((durations>1440).sum()),
                non_cadence_multiple_gaps=int(((durations/step-(durations/step).round()).abs()>1e-9).sum())))
    frequency=pd.DataFrame(freq);gaps=pd.DataFrame(gap_summary);gap_detail=pd.concat(gap_parts,ignore_index=True)
    bridge=pd.DataFrame(bridges)
    # Preserve UTC timezone formatting for details; pandas conversion through to_numpy may drop tz.
    for col in ['previous_observation_utc','next_observation_utc']:
        gap_detail[col]=pd.to_datetime(gap_detail[col],utc=True)

    # Step 5 DST: UTC transitions of Europe/Madrid on hourly grid, +- 2h inclusive.
    grid=pd.date_range('2020-01-01','2026-01-01',freq='h',tz='UTC')
    offsets=pd.Series([v.utcoffset().total_seconds()/3600 for v in grid.tz_convert('Europe/Madrid')],index=grid)
    transitions=offsets.loc[offsets.ne(offsets.shift())].iloc[1:]
    dst_summ=[];dst_parts=[]
    for transition,new_offset in transitions.items():
        old_offset=float(offsets.loc[transition-pd.Timedelta(hours=1)])
        kind='Spring forward' if new_offset>old_offset else 'Autumn back'
        w=df.loc[df.utc.between(transition-pd.Timedelta(hours=2),transition+pd.Timedelta(hours=2))].copy()
        for (zone,sensor),g in df.groupby(['zone','sensor'],sort=True):
            sub=w[(w.zone==zone)&(w.sensor==sensor)].sort_values('utc')
            before=sub[sub.utc<transition];after=sub[sub.utc>=transition]
            dst_summ.append(dict(zone=zone,sensor=sensor,transition_type=kind,
                transition_utc=transition.strftime('%Y-%m-%d %H:%M:%S'),old_offset_hours=old_offset,
                new_offset_hours=float(new_offset),observations_within_2h=len(sub),
                has_observations_both_sides_2h=bool(len(before)>0 and len(after)>0),
                repeated_local_rows_within_2h=int(sub.duplicated(['local'],keep=False).sum()),
                duplicate_utc_rows_within_2h=int(sub.duplicated(['utc'],keep=False).sum()),
                observed_utc_in_window=','.join(sub.utc.dt.strftime('%Y-%m-%d %H:%M:%S').tolist())))
            if len(sub):
                tmp=sub[['zone','sensor','Timestamp','timestamp_madrid','utc']].copy()
                tmp.insert(2,'transition_type',kind);tmp.insert(3,'transition_utc',transition.strftime('%Y-%m-%d %H:%M:%S'))
                tmp['offset_hours']=[v.utcoffset().total_seconds()/3600 for v in tmp.utc.dt.tz_convert('Europe/Madrid')]
                dst_parts.append(tmp.drop(columns='utc'))
    dst_summary=pd.DataFrame(dst_summ)
    dst_details=pd.concat(dst_parts,ignore_index=True)

    # Assertions are about self-consistency, not proof of underlying sensor cadence.
    if int(frequency.observations.sum())!=len(df) or int((frequency.intervals+1).sum())!=len(df):
        raise AssertionError('Frequency counts do not reconcile with source rows')
    if int(gaps.gap_intervals.sum())!=len(gap_detail):
        raise AssertionError('Gap summary does not reconcile with detail rows')
    if int(dup_df.utc_duplicate_rows.sum())!=int(utc_dup.sum()):
        raise AssertionError('Duplicate summary mismatch')
    if int(dup_df.local_repeated_rows.sum())!=len(local_repeat):
        raise AssertionError('Local clock repeat mismatch')
    if len(dst_summary)!=len(transitions)*len(dup_df):
        raise AssertionError('DST coverage reconciliation failed')
    outputs={'Task2_Frequency_Analysis.csv':frequency,'Task2_Gap_Summary.csv':gaps,
        'Task2_Gap_Details.csv':gap_detail,'Task2_Cross_Regime_Gaps.csv':bridge,
        'Task2_Step4_Duplicate_Invalid_Summary.csv':dup_df,'Task2_Step4_Local_Repeats.csv':local_repeat,
        'Task2_DST_Transition_Summary.csv':dst_summary,'Task2_DST_Transition_Observations.csv':dst_details}
    for name,frame in outputs.items():
        frame.to_csv(outdir/name,index=False)
    print(f'PASS: {len(df):,} observations; {len(dup_df)} series; {len(frequency)} series-periods')
    print(f'PASS: {bad_utc.sum()} invalid UTC; {mismatches.sum()} Madrid conversion mismatches; {utc_dup.sum()} duplicate UTC rows')
    print(f'PASS: {len(gap_detail):,} candidate gaps; {gaps.estimated_missing_observations.sum():,} estimated missing cadence positions')
    print(f'PASS: {len(local_repeat)} repeated local-time rows; {len(transitions)} calendar DST transitions')
    print(f'OUTPUT: {len(outputs)} CSV files in {outdir.resolve()}')
    return outputs

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('input_csv',type=Path,help='Merged dataset with Timestamp UTC and timestamp_madrid')
    p.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent/'results')
    a=p.parse_args()
    run(a.input_csv,a.output_dir)

if __name__=='__main__':
    main()
