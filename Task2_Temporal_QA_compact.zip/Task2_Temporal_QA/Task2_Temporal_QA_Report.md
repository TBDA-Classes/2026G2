# CeDInt Storey 1 — Sprint 2
# Task 2: Temporal Quality Assurance Report

**Project:** Tools for Big Data Analysis — CeDInt Storey 1  
**Scope:** NE, NW, SE and SW; cleaned energy sensor observations  
**Status:** Temporal QA analysis completed; proposed treatments await relevant team decisions  
**Source dataset:** `Storey1_ALL_ZONES_MERGED2.csv`  
**Reference framework:** `TBDA_Group2_Sprint2.pdf`, Sprint 2 Task 2; Mert's Task 1 `timestamp_note.md` and `timestamp_qa_report.csv`  
**Data handling:** Read-only QA; no source rows modified, deleted, synthesized or imputed

> **Reader's guide.** This report documents the complete Task 2 workflow in six analytical steps: (1) verify the Task 1 time convention and input integrity, (2) analyse observation frequencies, (3) identify candidate gaps, (4) check duplicate and invalid timestamps, (5) audit DST transitions, and (6) register treatment recommendations. Steps 1 and 2 connect this work to Sprint 2 Tasks 1–3, but this document is specifically **Task 2's temporal QA deliverable**, not a claim that the entire Sprint 2 modelling dataset has been frozen or its modelling decisions approved.

## Executive summary

The merged CeDInt Storey 1 dataset contains **1,273,456 observations**, **four spatial zones**, and **17 distinct zone–sensor series**. It retains an original `Timestamp` interpreted as UTC and a derived, timezone-adjusted `timestamp_madrid` column. The audit finds **two observed dominant sampling cadences**: approximately **60 minutes** during 2020–2023 and **one minute** during 2025. Of 17 historical zone–sensor series, 16 also have recent observations (hence **33 series–period combinations**); **SW/RACK** has no 2025 data.

Within these regimes, the audit flags **119,924 candidate gap intervals** (826 historical; 119,098 recent). Under the *working assumptions* of continuous 60-minute historical and 1-minute recent sampling, these correspond to **435,223 estimated missing cadence positions** (17,025 and 418,198, respectively). This is **not a count of verified lost source records**: expected device sampling rates have not been independently confirmed. Sixteen series show an approximately **901.82-day discontinuity** between 28 February 2023 and 18 August 2025. That between-regime interval is **reported separately and excluded from missing-slot estimates**.

No invalid UTC timestamps, duplicate `(zone, sensor, Timestamp)` records, or UTC-to-Madrid conversion mismatches were found. **100 rows** represent **50 pairs of repeated Madrid wall-clock timestamps** at autumn daylight-saving transitions; they have different UTC timestamps and are **not actual duplicates**. Five of 12 calendar DST transitions from 2020 to 2025 are covered by observations around the transition and can be assessed; the remaining seven cannot be assessed from those windows.

**Overall assessment:** chronological keys and timezone conversion are consistent; **temporal completeness and comparability require caution**. Preserve original records, existing quality flags and UTC chronology, explicitly segment the disjoint regimes, and defer resampling/imputation/model scope decisions until the expected sensor cadence and modelling specification are agreed.

## 1. Purpose, requirements, and analytical boundary

### 1.1 What Task 2 requires

Sprint 2 Task 2, *Perform temporal quality checks*, asks the Data Team to (i) measure intervals between observations in relevant series; (ii) identify hourly, minute-level and irregular periods; (iii) check duplicates, missing intervals and unexpected gaps; (iv) check DST transition periods; and (v) **record treatment decisions rather than silently correcting everything**. Its exit condition is that the team can clearly describe the temporal structure and planned treatment of each relevant period. Task 2 depends on the Task 1 timestamp convention and informs the four-zone merge and subsequent modelling work.

### 1.2 What this report does—and does not—claim

- **Does:** audit the existing merged file, quantify observed temporal characteristics, describe limits and propose treatments traceable to numeric evidence.
- **Does not:** rewrite the sensor values, certify hardware configuration, prove which readings were genuinely lost, assert the model's target/horizon, or decide whether to use one model or several.
- **Provenance boundary:** Mert's Task 1 established a documented **UTC source-time assumption**. Recomputing the local conversion confirms its implementation; it cannot independently prove the acquisition device originally emitted UTC without system metadata.

### 1.3 Inputs and lineage

| Input | Role |
|---|---|
| `CLEAN DATA all zones.zip` | Source cleaned data for NE, NW, SE and SW; each zone includes `CLEAN_DATA`, audit, correction log, rules, counter events, sensor quality and run configuration. |
| `Task1_documentsMERT.zip` | Task 1 Python conversion, `timestamp_note.md`, `timestamp_qa_report.csv`: UTC interpretation, timezone conversion, DST convention, prior QA and open points. |
| `Storey1_ALL_ZONES_MERGED2.csv` | **Read-only working input** for this temporal QA: records of the four zones plus `zone` and `timestamp_madrid`. |
| `TBDA_Group2_Sprint2.pdf` | Official execution-plan requirements and sequencing. |

The merged dataset was cross-checked in Step 1 against cleaned values and Task 1 time conversion. This check qualifies the merged file as a **working QA input**, **not** as final sign-off for the independent Sprint 2 Task 3 merge or Task 4 dataset freeze.

## 2. Step 1 — Verify Task 1 assumptions and the working input

### 2.1 Why verification is needed

All subsequent interval and duplicate calculations require an unambiguous chronological key. A naive use of Madrid wall-clock labels could create false duplicates in autumn and false missing hours in spring. Before temporal QA we therefore checked that the merged file preserves original UTC timestamps and accurately adds local time.

### 2.2 Timestamp convention inherited from Task 1

| Field | Meaning and permitted use |
|---|---|
| `Timestamp` | Original timestamp, **interpreted as UTC**. Canonical key for sorting, per-sensor time differences and temporal joins. |
| `timestamp_madrid` | Local representation of the **same instant**, converted to `Europe/Madrid` (CET/CEST). Useful for hour/day/weekday/holiday features. The text field itself omits the UTC offset, so it is not a unique chronological key. |
| `(zone, sensor, Timestamp)` | The relevant duplicate key: observations at the same UTC instant from different sensors are legitimate. |

Task 1's UTC rationale includes no DST jumps in historical source timestamps and approximate alignment of outdoor-lighting patterns with Madrid sunrise/sunset. These are *evidence supporting the convention*, not an independent hardware-config audit. Task 1 retained all source timestamp rows.

### 2.3 Input integrity results

| Zone | Observations | Zone–sensor series |
|---|---:|---:|
| NE | 175,545 | 2 |
| NW | 525,622 | 6 |
| SE | 283,605 | 4 |
| SW | 288,684 | 5 |
| **Total** | **1,273,456** | **17** |

The Step 1 reconciliation found no unexplained loss of records relative to the original cleaned files; existing cleaned values and quality flags were preserved. All 1,273,456 UTC-to-Madrid conversions matched the expected `Europe/Madrid` conversion. The initial checks returned **zero invalid UTC timestamps** and **zero `(zone,sensor,UTC)` duplicates**; both findings were retested independently in Step 4.

**Step 1 outcome:** accept the merged file as this report's immutable analytical input, retain the Task 1 UTC/Madrid distinction and explicitly carry forward the open issues of mixed sampling cadence and the historical–recent discontinuity.

## 3. Step 2 — Observation frequency analysis

### 3.1 Objective and method

**Question:** How frequently does each sensor actually record, and does that frequency change over time?

For every `(zone, sensor)`, observations were sorted by **UTC**. The data were divided into two empirically observed periods: **Historical (2020–2023)** and **Recent (2025)**. The implementation uses a dataset-specific UTC cut at 2024-01-01 solely to separate these non-overlapping recorded periods; it is **not a generic cadence-detection algorithm**. Within each period, successive differences were computed:

`delta_i_minutes = (UTC_i - UTC_(i-1)) / 1 minute`.

We counted the occurrence of 1-minute and 60-minute intervals and other positive intervals, identified the **mode** (most frequent actual observed interval), and calculated its share as `mode_count / number_of_within_period_intervals × 100`. Each series with `n` observations contributes `n − 1` within-period intervals. The 2023–2025 interval was excluded here and treated separately in Step 3.

### 3.2 Period coverage and consistency

| Period | Series–periods | Observations | Within-period intervals | Dominant interval | Range of modal-frequency shares |
|---|---:|---:|---:|---|---|
| Historical 2020–2023 | 17 | 405,382 | 405,365 | 60 min | 99.42%–99.93% |
| Recent 2025 | 16 | 868,074 | 868,058 | 1 min | 70.48%–93.05% |
| **Total** | **33** | **1,273,456** | **1,273,423** | Mixed | — |

The interval total is lower than the observation total by 33, because each within-period series has no preceding in-period observation for its first row.

### 3.3 Per-sensor dominant-frequency shares

| Zone | Sensor | Historical, 60-minute share | Recent, 1-minute share |
|---|---|---:|---:|
| NE | HVAC | 99.93% | 90.99% |
| NE | Plugs & Sockets | 99.93% | 93.01% |
| NW | Emerg. Lighting | 99.91% | 92.90% |
| NW | HVAC | 99.91% | 92.84% |
| NW | Hand Dryer | 99.93% | 92.95% |
| NW | Lighting | 99.93% | 92.99% |
| NW | Plugs & Sockets | 99.93% | 93.05% |
| NW | RACK | 99.93% | 91.34% |
| SE | Emerg. Lighting | 99.80% | 70.50% |
| SE | HVAC | 99.80% | 70.48% |
| SE | Lighting | 99.87% | 79.85% |
| SE | Plugs & Sockets | 99.89% | 88.47% |
| SW | Emerg. Lighting | 99.43% | 74.00% |
| SW | Hand Dryer | 99.42% | 71.04% |
| SW | Lighting | 99.74% | 83.59% |
| SW | Plugs & Sockets | 99.56% | 76.50% |
| SW | RACK | 99.46% | **No recent observations** |

**Interpretation:** hourly sampling is highly regular in the historical subset; in 2025 the one-minute mode is substantially less dominant, especially for **SE/HVAC (70.48%)**, **SE/Emerg. Lighting (70.50%)**, and **SW/Hand Dryer (71.04%)**. A non-modal interval is *not by itself* proof of a lost reading or sensor failure. Rates are per series and should not be conflated with absolute counts of irregular intervals.

**Step 2 evidence:** `results/Task2_Frequency_Analysis.csv` (33 summary rows).

## 4. Step 3 — Missing intervals and candidate gap analysis

### 4.1 Objective, assumptions and counting rules

**Question:** Where and for how long do observation intervals exceed the working sampling cadence?

For this *diagnostic* analysis, a working reference interval was assigned to each recorded regime: **60 minutes historical**, **1 minute recent**. For each pair of consecutive UTC observations *within the same series and regime*, an interval was flagged when `delta > reference cadence`.

The number of **conditional missing cadence positions** is the count of complete expected sampling slots strictly between the two observed times. For exact cadence multiples, for example `10:02 → 10:07` under a 1-minute expectation, `delta = 5 minutes`, so **4 intermediate slots** are absent. When an interval is not an exact cadence multiple, the calculation remains an approximate grid-based diagnostic, not proof that a reading was scheduled at every implied timestamp. These assumptions must be verified with the acquisition team before speaking of confirmed lost data.

**Critical distinction:** a *gap interval* is one observed longer-than-reference time difference; a *missing-slot estimate* is the inferred number of expected intermediate time positions. The two are not interchangeable. Neither metric incorporates the historical–recent interruption across the regime boundary.

### 4.2 Main quantitative findings

| Recorded regime | Candidate gap intervals | Conditional missing cadence positions |
|---|---:|---:|
| Historical (hourly reference) | 826 | 17,025 |
| Recent 2025 (one-minute reference) | 119,098 | 418,198 |
| **Total within regimes** | **119,924** | **435,223** |

These missing positions are counted **by zone–sensor series**. A timestamp missing simultaneously in four sensors counts as four candidate missing positions; the total does not count unique minutes of building-wide downtime.

**Recent candidate gap intervals by zone:** NE **10,023**; NW **27,699**; SE **39,762**; SW **41,614** (sum **119,098**). These absolute counts are affected by observation volume and number/coverage of sensors. They must not be presented as a definitive ranking of the zones' reliability; normalised gap share by series, duration, and coverage are also required.

### 4.3 The large between-regime discontinuity

For 16 sensors having both historical and recent records, the last historical sample is **2023-02-28 23:00 UTC** and the first recent sample is **2025-08-18 18:43 or 18:44 UTC**. The elapsed interval is approximately **901.822 days** (depending slightly on which first minute is observed). It is a real *observation-coverage discontinuity*, but we do not know whether the devices were meant to transmit continuously throughout it or whether a recording/export interruption occurred.

It is therefore **reported separately, not imputed and not converted to a giant count of missing hourly/minute measurements**. Constructing a uniform time grid across it would invent a large amount of unsupported data. In time-series modelling, lag and rolling windows must not cross this break.

**Exception:** `SW / RACK` ends at **2021-12-03 17:00 UTC**; there is no recent portion of that series. Thus it has no observed 2023-to-2025 bridge of its own and cannot automatically be included in 2025 forecasting.

### 4.4 Major internal interruption

Within the historical regime, the largest consecutive-observation interval found was **37 days** (`2021-05-12 08:00` to `2021-06-18 08:00` UTC), observed for **NW/Emerg. Lighting** and **NW/HVAC**. Under the hourly working cadence this corresponds to **887 intermediate hourly positions per sensor**. This is an internal coverage anomaly, distinct from the much larger 2023–2025 break.

Other short gaps, including 2–4 minute recent intervals, warrant examination by sensor and by date. They cannot yet be labelled proven data loss without expected sample-rate evidence.

### 4.5 Implications

- Maintain a **gap log** with sensor, zone, UTC start/end, duration, working cadence and conditional slot estimate.
- Do not silently remove, interpolate or synthesise observations during Task 2.
- Use the 2023–2025 discontinuity as a segmentation boundary for feature windows.
- Confirm whether one-minute capture was mandated for each recent sensor before selecting a uniform grid or calculating final completeness rates.

**Step 3 evidence:** `Task2_Gap_Summary.csv` (33 rows), `Task2_Gap_Details.csv` (119,924 candidate intervals), `Task2_Cross_Regime_Gaps.csv` (17 series); methodology recorded in `Task2_Step3_Gap_Analysis_Notes.md`.

## 5. Step 4 — Duplicate and invalid timestamp audit

### 5.1 Checks performed

Each observation was assessed for valid parseable UTC time, valid local Madrid time, missing zone/sensor identity, time-zone conversion consistency and duplicate **`(zone, sensor, UTC)`** keys. The last key matters: identical times on two separate sensors do not constitute duplicates. We separately examined repeated **Madrid local wall-clock labels**, which are expected under autumn DST fallback.

### 5.2 Results

| Zone | Sensor series | Invalid UTC | Duplicate series–UTC rows | Repeated local-clock rows |
|---|---:|---:|---:|---:|
| NE | 2 | 0 | 0 | 12 |
| NW | 6 | 0 | 0 | 36 |
| SE | 4 | 0 | 0 | 24 |
| SW | 5 | 0 | 0 | 28 |
| **Total** | **17** | **0** | **0** | **100** |

Across all 1,273,456 observations, there were **0 invalid local timestamps**, **0 missing zone/sensor identifiers**, and **0 Madrid conversion mismatches**. The 100 locally repeated rows form **50 pairs**, each pair containing **two distinct UTC instants**; they are not duplicates and should be retained.

**Illustration:** on 2020-10-25, `00:00 UTC → 02:00 CEST (UTC+2)` while `01:00 UTC → 02:00 CET (UTC+1)`. The Madrid clock label alone cannot distinguish them; `Timestamp` in UTC can.

**Step 4 evidence:** `Task2_Step4_Duplicate_Invalid_Summary.csv` (17 rows), `Task2_Step4_Local_Repeats.csv` (100 rows).

## 6. Step 5 — Daylight-saving-time transition audit

### 6.1 Objective and procedure

**Question:** Are the apparent local spring missing hour and autumn repeated hour handled consistently without spurious source UTC gaps or duplicates?

All local values were compared with timezone-aware UTC → `Europe/Madrid` conversion. We identified official spring/autumn transitions from 2020 to 2025 and inspected a **two-hour UTC window on either side** for each zone–sensor series. A transition was considered *covered* only when observations existed on both sides of that transition within those windows. Uncovered events were designated **not assessable**, never silently called correct or incorrect.

### 6.2 Transition coverage

| Transition date | Type | Series covered on both sides | Repeated local rows |
|---|---|---:|---:|
| 2020-10-25 | Autumn fallback | 17 of 17 | 34 |
| 2021-03-28 | Spring forward | 17 of 17 | 0 |
| 2021-10-31 | Autumn fallback | 17 of 17 | 34 |
| 2022-03-27 | Spring forward | 16 of 17 | 0 |
| 2022-10-30 | Autumn fallback | 16 of 17 | 32 |
| **Five covered transitions** | | | **100** |

In total there are **12 calendar transitions from 2020 through 2025**; **seven** have no relevant observed coverage around their transition and cannot be assessed. The 2020 spring event predates first observations; later uncovered events fall outside observed data windows. `SW/RACK` is absent in 2022 because its series ends in 2021.

**Spring:** local 02:00–02:59 does not occur when clocks advance; no UTC hour needs inventing. **Autumn:** the local 02:00 hour occurs twice with different UTC offsets; those observations are retained as unique UTC records. No DST-specific source-time correction is justified by these checks.

### 6.3 Important limit

Agreement with a timezone conversion demonstrates that `timestamp_madrid` is **correctly derived from the assumed UTC source column**. It does *not* independently establish the raw acquisition-system time zone. This provenance remains a Task 1 convention requiring confirmation from device/system metadata, if obtainable.

**Step 5 evidence:** `Task2_DST_Transition_Summary.csv` (12 × 17 = 204 audit rows), `Task2_DST_Transition_Observations.csv` (415 inspected observations), and `Task2_Step5_DST_Analysis_Notes.md`.

## 7. Step 6 — Treatment recommendations and decision register

### 7.1 Principles

The Task 2 mandate is **transparent documentation**, not unapproved data rewriting. Recommendations distinguish actions that follow directly from timestamp semantics from modelling design decisions that must be agreed with the relevant team. All decisions below are **proposed or pending owner confirmation**, except the already adopted read-only QA practice and established time-key convention for this analysis.

| ID | Supported observation | Recommended action | Status / owner |
|---|---|---|---|
| **D01** | Hourly historical and minute-level recent regimes | Preserve observed resolutions; consider aggregation only once target, unit and forecasting horizon are chosen. Do not fabricate minute readings from hourly data. | **Proposed** — Modelling |
| **D02** | ~901.82-day historical–recent discontinuity | Preserve as a break; segment the regimes; prohibit lag/rolling windows crossing the gap. | **Proposed** — Data + Modelling |
| **D03** | 119,924 candidate gaps; 435,223 conditional missing positions | Retain gap flags/log; confirm per-device sampling specification before asserting readings were lost. | **Open** — Data owner |
| **D04** | Unequal cadence regularity across sensors/zones | Compare coverage-normalised completeness and operational relevance before model-scope choice. | **Proposed** — Modelling |
| **D05** | SW/RACK has no recent data | Do not use SW/RACK as an observed input/target in 2025-specific models; keep its historical records for potentially valid historical analysis. | **Proposed** — Modelling |
| **D06** | DST autumn local repeats have distinct UTC | Use UTC for chronological keys; retain local times for features plus UTC/offset to disambiguate; do not delete autumn repeats or insert nonexistent spring times. | **Recommended convention** — Data + Modelling |
| **D07** | Cleaned sensor records carry counter events/quality flags | Preserve sensor cleaning provenance, counter reset indicators and sensor-quality assessments; establish target suitability separately from temporal QA. | **Proposed** — Data + Modelling |
| **D08** | 2025 missing slots remain conditional | Do not impute in Task 2; later evaluate exclusion, aggregation or training-only imputation against documented missingness policy. | **Open** — Modelling |
| **D09** | Raw UTC origin inferred from Task 1 evidence | Continue current UTC convention, explicitly flag its provenance assumption and verify acquisition configuration if possible. | **Open** — Data owner |

### 7.2 Why these recommendations matter

**Time-grid harmonisation is a modelling decision.** For example, hourly **power** measurements and cumulative **energy meter** readings cannot necessarily be aggregated using the same function. Blind sums, averages or interpolation could introduce incorrect physical units or destroy counter-reset information. The choice should follow the selected target and measurement semantics, not convenience.

**Gap filling can create leakage.** Interpolation using later observations may accidentally provide future information for a forecasting problem. The modelling team should first decide the chronological train/validation/test split and what information would genuinely be available at prediction time.

**Temporal QA is not sensor-quality QA.** A complete timestamp sequence can contain unreliable energy measurements, and a good energy sensor can have temporal gaps. The existing `sensor_quality` and `counter_events` files must therefore remain linked to modelling decisions.

### 7.3 Questions requiring explicit team resolution

1. Is 60-minute historical / 1-minute recent acquisition the **configured sampling schedule for each device**, or only the observed dominant cadence?
2. What is the **first prediction target**, its physical unit, forecast horizon, and required time resolution?
3. Will the first model use historical and recent periods separately, jointly under explicit segmentation, or only one regime?
4. Which devices are eligible as forecasting targets according to `sensor_quality` and counter-reset documentation?
5. Can the data owner corroborate the original UTC time convention using acquisition-system settings or logs?
6. What completeness threshold, maximum consecutive gap, or missing-data policy should qualify training/validation/test segments?

**Step 6 evidence:** `Task2_Treatment_Decision_Register.csv` (9 decisions) and `Task2_Step6_Treatment_Decisions.md`. These are recommendations, **not a signed modelling approval**.

## 8. Overall QA assessment and handover guidance

| Dimension | Finding | Handover consequence |
|---|---|---|
| Chronological key | 0 invalid UTC; 0 duplicated `(zone,sensor,UTC)` | UTC suitable for sorting/joins within the accepted time-origin convention. |
| Madrid time conversion | 0 mismatches | Use local time for calendar attributes; retain UTC for unique ordering. |
| Sampling homogeneity | Mixed historical hourly and recent minute cadence | Declare and preserve regime boundaries; do not silently resample. |
| Completeness | 119,924 candidate larger-than-reference intervals; conditional slot estimate 435,223 | Device-level cadence confirmation needed for true missingness conclusions. |
| Historical–recent coverage | ~901.82-day observed discontinuity for 16 series | No synthetic bridge and no cross-break lag features. |
| Special sensor coverage | SW/RACK stops December 2021 | Exclude from datasets requiring observed SW/RACK 2025 values. |
| DST handling | 5 transitions directly assessable; 50 legitimate repeated-local-time pairs | No DST-only row deletion or insertion; keep UTC/offset context. |
| Data governance | Cleaning/quality provenance exists | Preserve flags, traceability and source files for modelling handover. |

### Task 2 exit-condition assessment

- **Met:** describe temporal structure and observation-frequency differences by series and regime.
- **Met:** identify candidate gaps, quantify conditional missing slots, check duplicates and validate covered DST transitions.
- **Met:** document treatment recommendations rather than applying silent corrections.
- **Pending external decisions:** confirm device expected cadence and original timezone provenance; choose modelling target/resolution, sensor scope and any downstream missing-data treatment.

**Conclusion:** the available dataset is ready for a **documented handover of temporal QA findings**, but a future modelling dataset should not be described as fully temporally complete, harmonised or formally frozen solely on the basis of Task 2. The next Sprint 2 activities—merge/final QA and modelling preparation—must explicitly incorporate these caveats.

## 9. Reproducibility and evidence index

All intermediate analyses were performed **without changing the underlying merged CSV**. The evidence CSVs listed below are **not bundled with this compact GitHub package**; the eight quantitative result CSVs can be regenerated by running `task2_temporal_qa.py` on the upstream merged dataset. The manually maintained treatment decision register is not bundled and is not generated by the script; its recommendations and open questions are summarised in Section 7. Relevant audit artefacts:

| Step | Evidence file | Purpose / record count |
|---|---|---|
| 1 | Mert's `timestamp_note.md`, `timestamp_qa_report.csv`; source cleaned ZIP and merged CSV | Input, convention, lineage and counts. |
| 2 | `results/Task2_Frequency_Analysis.csv` | 33 series–regime frequency summaries. |
| 3 | `Task2_Gap_Summary.csv` | 33 gap summaries. |
| 3 | `Task2_Gap_Details.csv` | 119,924 within-regime candidate gap intervals. |
| 3 | `Task2_Cross_Regime_Gaps.csv` | 17 series' cross-regime coverage/exception. |
| 4 | `Task2_Step4_Duplicate_Invalid_Summary.csv` | 17 series duplicate/validity summaries. |
| 4 | `Task2_Step4_Local_Repeats.csv` | 100 rows with repeated Madrid clock labels. |
| 5 | `Task2_DST_Transition_Summary.csv` | 204 series × DST-transition checks. |
| 5 | `Task2_DST_Transition_Observations.csv` | 415 observations in DST inspection windows. |
| 6 | `Task2_Treatment_Decision_Register.csv` | 9 proposed/pending treatments and owners. |

### Reproduction and sign-off protocol (next work package)

The consolidated script `task2_temporal_qa.py` was built and successfully run against the merged source CSV, including a successful execution on Windows in VS Code. It generates the eight evidence files in `results/`; the separately maintained treatment decision register (not part of this compact delivery) records human recommendations. The run reported 1,273,456 observations, 17 zone-sensor series, 33 series-periods, 119,924 candidate gaps, 435,223 estimated cadence positions and 100 repeated local-time rows. Results were compared to the earlier step-level outputs. To reproduce the analysis use the command in `README.md`. The script validates required input columns and timezone conversion, but the inferred reference cadences still require source-system confirmation. A final team handover should record the source-file hash, run environment and owner approvals.

## 10. Limitations and interpretation safeguards

1. **Not all irregular intervals are missing readings.** Sampling rates inferred from modal differences may differ from the system's configured cadence; actual source logs are needed for validation.
2. **Estimated missing positions are conditional, not ground truth.** The totals sum by sensor, not by unique global timestamps, and exclude the bridge between regimes.
3. **DST assessability is coverage-limited.** Seven calendar transitions cannot be checked from nearby data; absent coverage is not an error or a successful DST test.
4. **Source-time provenance is assumed.** The source UTC convention is reasoned from Task 1 evidence; a correct UTC-to-Madrid calculation by itself does not prove original UTC emission.
5. **The report does not validate energy measurements or target suitability.** Refer to the Sprint 1 sensor quality and counter-event artefacts.
6. **Analysis is specific to this dataset.** The historical/recent cutoff and 60/1-minute working reference cadences are not generic settings for unrelated datasets.
7. **Handover is not model approval.** Targets, physical units, aggregation method, acceptable missingness and splitting must be signed off by the relevant teams.

---

**End of Task 2 Temporal QA report.**  
**Next activity:** hand over the consolidated Python audit and evidence package; record approvals for the open decisions before downstream modelling.
