"""Chronos wrapper — toy-data tests (no model weights needed: the model call is replaced by a stub)."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import chronos_model as CM
from task7_baselines import forecast_tasks


def toy(n=24 * 30):
    hrs = pd.date_range("2025-08-19", periods=n, freq="h", tz="UTC")
    rows = []
    for s, base in [("A|x", 10.0), ("B|y", 100.0)]:
        y = base + np.arange(n, dtype=float)
        y[50:53] = np.nan                                   # invalid hours stay NaN
        rows.append(pd.DataFrame({"series_id": s, "hour_utc": hrs, "energy_Wh": y}))
    h = pd.concat(rows, ignore_index=True)
    h["split"] = np.where(h.hour_utc < hrs[24 * 20], "train", np.where(h.hour_utc < hrs[24 * 25], "validation", "test"))
    return h


def test_context_only_uses_hours_before_issue_time():
    h = toy(); g = CM.series_grid(h)["A|x"]
    tau = g.index[400]
    c = CM.context(g, tau, 168)
    assert len(c) == 168 and c[-1] == g.iloc[399]
    g2 = g.copy(); g2.iloc[400:] = -999.0                   # change everything from the issue time on
    assert np.array_equal(CM.context(g2, tau, 168), c, equal_nan=True)


def test_missing_hours_stay_missing():
    g = CM.series_grid(toy())["A|x"]
    c = CM.context(g, g.index[60], 20)
    assert np.isnan(c).sum() == 3


def test_leads_read_from_the_right_step(monkeypatch):
    h = toy()
    # stub: quantile k of step j = 1000*j + k  -> lead L must read step L-1
    def fake(pipe, ctxs):
        q = np.zeros((len(ctxs), CM.PRED_LEN, 3), dtype="float32")
        q += (1000 * np.arange(CM.PRED_LEN))[None, :, None] + np.arange(3)[None, None, :]
        return q
    monkeypatch.setattr(CM, "_predict", fake)
    for hz, L in [("+1h", 1), ("+6h", 6)]:
        t = forecast_tasks(h, hz, "validation")
        P = CM.chronos_forecasts(None, h, t, 168)
        assert (P["y_pred"] == 1000 * (L - 1) + 1).all() and (P["q10"] < P["y_pred"]).all()
    t = forecast_tasks(h, "day-ahead", "validation")
    P = CM.chronos_forecasts(None, h, t, 168)
    assert (P["y_pred"] == 1000 * (P["lead"] - 1) + 1).all()
    assert len(P) == len(t)
