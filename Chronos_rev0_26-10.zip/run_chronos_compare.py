"""Sprint 3 — compare Chronos-Bolt with the baselines B1, B2, B3 and Model 1 (gradient boosting, Task 8).

    python run_chronos_compare.py

All five models are scored on exactly the same hours in each block (common mask, protocol §8).
Scaled MAE = per circuit MAE / circuit training mean (per-horizon scale of the Task 8 freeze), averaged over
the 8 circuits — the selection metric of Task 8.

Blocks
- validation, test                      official results
- test without 2 events                 Task 8 definition: drops only the event HOURS (NE|HVAC on 3 Oct Madrid,
                                         NW|Emerg. Lighting hours with energy > 2x power and > 20 Wh)

Writes results/chronos_comparison.xlsx, results/chronos_tables.md
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd

import config as C
import chronos_model as CM
from task7_baselines import load_derived, KEY

MODELS = ["B1_last_week", "B2_weekday_hour_median", "B3_persistence", "ML_GBM", "ML_Chronos"]
SHORT = dict(zip(MODELS, ["B1", "B2", "B3", "GBM", "Chronos"]))
HZ = list(C.HORIZONS)

cfg8 = json.loads(Path(C.FROZEN_CONFIG).read_text())
cfgc = json.loads(Path("models/chronos_frozen_config.json").read_text())
SCALE = {hz: pd.Series(cfg8["horizons"][hz]["scale_Wh"]) for hz in HZ}
h = load_derived(C.DERIVED_PATH)

cols = ["series_id", "issue_time", "target_time", "lead", "horizon", "split", "y_true", "y_pred", "model"]
P = pd.concat([pd.read_parquet(f"results/{f}")[cols] for f in [
    "task8_validation_predictions.parquet", "task8_test_predictions.parquet",
    "chronos_validation_predictions.parquet", "chronos_test_predictions.parquet"]], ignore_index=True)
assert set(P["model"]) == set(MODELS), set(P["model"])
assert not P.duplicated(KEY + ["model"]).any()
Q = pd.concat([pd.read_parquet(f"results/chronos_{s}_predictions.parquet") for s in ("validation", "test")])

# ---------------------------------------------------------------- masks
def common(P):
    ok = P.assign(ok=P["y_true"].notna() & P["y_pred"].notna()).groupby(KEY)["ok"].agg(["all", "size"])
    keep = ok[ok["all"] & (ok["size"] == len(MODELS))].index
    return P.set_index(KEY).loc[lambda d: d.index.isin(keep)].reset_index()


def event_mask(P):
    x = h[(h.series_id == "NW|Emerg. Lighting") & h.energy_valid & h.W_valid]
    bad = set(x.loc[(x.energy_Wh / x.W_mean > 2) & (x.energy_Wh > 20), "hour_utc"])
    loc = P["target_time"].dt.tz_convert(C.TZ_LOCAL).dt.date.astype(str)
    return ((P.series_id == "NE|HVAC") & (loc == "2025-10-03")) | ((P.series_id == "NW|Emerg. Lighting") & P.target_time.isin(bad))


CP = common(P)
lost = {m: int((P[P.model == m].y_true.notna() & P[P.model == m].y_pred.isna()).sum()) for m in MODELS}
T = CP[CP.split == "test"]
blocks = {"validation": CP[CP.split == "validation"], "test": T,
          "test without 2 events": T[~event_mask(T)]}

# ---------------------------------------------------------------- scores
def per_series(B):
    g = B.assign(ae=(B.y_true - B.y_pred).abs()).groupby(["horizon", "model", "series_id"])["ae"].mean().rename("MAE")
    g = g.reset_index()
    g["scaled"] = [m / SCALE[hz][s] for hz, s, m in zip(g.horizon, g.series_id, g.MAE)]
    return g


rows, wins, ps_all = [], [], []
for name, B in blocks.items():
    g = per_series(B)
    ps_all.append(g.assign(block=name))
    for hz in HZ:
        gh = g[g.horizon == hz]
        w = gh.pivot(index="series_id", columns="model", values="MAE")
        r = dict(block=name, horizon=hz, hours=int(len(B[(B.horizon == hz)]) / len(MODELS)), circuits=len(w))
        exact = {m: gh[gh.model == m].scaled.mean() for m in MODELS}
        for m in MODELS:
            r[SHORT[m]] = round(exact[m], 3)
        r["best"] = SHORT[min(MODELS, key=exact.get)]                  # decided on unrounded values
        r["best_margin"] = round(sorted(exact.values())[1] - min(exact.values()), 4)
        rows.append(r)
        wins.append(dict(block=name, horizon=hz, **{f"Chronos better than {SHORT[m]}": f"{int((w['ML_Chronos'] < w[m]).sum())}/{len(w)}"
                                                   for m in MODELS[:-1]}))
summary, wins = pd.DataFrame(rows), pd.DataFrame(wins)
ps = pd.concat(ps_all, ignore_index=True)
ps_test = ps[ps.block == "test"].pivot_table(index=["horizon", "series_id"], columns="model", values="MAE").round(2)
ps_test = ps_test[MODELS].rename(columns=SHORT).reset_index()

# day-ahead by hours ahead (test without 2 events)
D = blocks["test without 2 events"].query("horizon == 'day-ahead'").copy()
D["bucket"] = pd.cut(D.lead, [0, 3, 6, 12, 18, 24], labels=["1–3", "4–6", "7–12", "13–18", "19–24"])
D["scaled_ae"] = (D.y_true - D.y_pred).abs() / D.series_id.map(SCALE["day-ahead"])
by_lead = (D.groupby(["bucket", "model", "series_id"], observed=True)["scaled_ae"].mean()
            .groupby(["bucket", "model"], observed=True).mean().unstack()[MODELS].rename(columns=SHORT).round(3).reset_index())

# ---------------------------------------------------------------- forecast ranges
rs = pd.concat([CM.range_stats(Q[Q.horizon == hz], SCALE[hz]) for hz in HZ], ignore_index=True)   # per-horizon scale
range_sum = (rs.groupby(["split", "horizon"]).apply(lambda d: pd.Series(dict(
    hours=d.hours.sum(), inside_10_90=np.average(d.inside_10_90, weights=d.hours),
    below_q10=np.average(d.below_q10, weights=d.hours), above_q90=np.average(d.above_q90, weights=d.hours))),
    include_groups=False).round(3).reset_index())
QT = Q[(Q.split == "test") & Q.y_true.notna()]
ev = QT[(QT.series_id == "NE|HVAC") & (QT.target_time.dt.tz_convert(C.TZ_LOCAL).dt.date.astype(str) == "2025-10-03")]
ev_hours = ev[ev.y_true > 50]
flag = (ev_hours.assign(above=ev_hours.y_true > ev_hours.q90).groupby("horizon")
        .agg(event_hours=("above", "size"), above_q90=("above", "sum"), max_q90_Wh=("q90", "max")).reset_index())
normal = QT[~event_mask(QT)]
false_flags = (normal.assign(f=normal.y_true > normal.q90).groupby("horizon")["f"].mean().round(3)
               .rename("share of normal test hours above q90").reset_index())
flag = flag.merge(false_flags, on="horizon")

# ---------------------------------------------------------------- write
tune = pd.read_csv("results/chronos_tuning_log.csv")
tune_w = tune.pivot(index="ctx_len", columns="horizon", values="score")[HZ].round(4).reset_index()
frozen = pd.DataFrame([dict(horizon=hz, **{k: v for k, v in c.items() if k != "scale_Wh"}) for hz, c in cfgc["horizons"].items()])
with pd.ExcelWriter("results/chronos_comparison.xlsx") as xw:
    summary.to_excel(xw, sheet_name="summary_scaled_MAE", index=False)
    wins.to_excel(xw, sheet_name="chronos_wins", index=False)
    ps_test.to_excel(xw, sheet_name="test_MAE_by_circuit", index=False)
    by_lead.to_excel(xw, sheet_name="dayahead_by_lead", index=False)
    range_sum.to_excel(xw, sheet_name="ranges_summary", index=False)
    rs.round(3).to_excel(xw, sheet_name="ranges_by_circuit", index=False)
    flag.to_excel(xw, sheet_name="NE_HVAC_event_flag", index=False)
    tune_w.to_excel(xw, sheet_name="tuning_validation", index=False)
    frozen.to_excel(xw, sheet_name="frozen_config", index=False)
    ps.round(4).to_excel(xw, sheet_name="per_series_long", index=False)
    pd.DataFrame([lost]).to_excel(xw, sheet_name="hours_lost_to_mask", index=False)
from openpyxl import load_workbook
wb = load_workbook("results/chronos_comparison.xlsx")
for ws in wb.worksheets:
    ws.freeze_panes = "A2"
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = min(40, max(9, *(len(str(x.value or "")) + 2 for x in col)))
wb.save("results/chronos_comparison.xlsx")

md = lambda d: d.to_markdown(index=False)
Path("results/chronos_tables.md").write_text("\n\n".join([
    "## Scaled MAE, same hours for all five models\n" + md(summary),
    "## Circuits where Chronos has the lower MAE\n" + md(wins),
    "## Test MAE by circuit (Wh per hour, all hours)\n" + md(ps_test),
    "## Day-ahead by hours ahead (scaled MAE, test without 2 events)\n" + md(by_lead),
    "## Chronos 10–90 % range\n" + md(range_sum),
    "## NE|HVAC run on 3 Oct vs Chronos q90\n" + md(flag),
    "## Validation tuning (context length)\n" + md(tune_w),
    f"Hours each model lost to the common mask: {lost}"]))
pd.set_option("display.width", 220)
print(summary.to_string(index=False)); print(wins.to_string(index=False)); print(range_sum.to_string(index=False))
print(flag.to_string(index=False)); print("lost to mask:", lost)
