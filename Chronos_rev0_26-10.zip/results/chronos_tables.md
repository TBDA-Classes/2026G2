## Scaled MAE, same hours for all five models
| block                 | horizon   |   hours |   circuits |    B1 |    B2 |    B3 |   GBM |   Chronos | best    |   best_margin |
|:----------------------|:----------|--------:|-----------:|------:|------:|------:|------:|----------:|:--------|--------------:|
| validation            | +1h       |    1120 |          8 | 0.578 | 0.427 | 0.29  | 0.246 |     0.246 | Chronos |        0.0005 |
| validation            | +6h       |    1120 |          8 | 0.578 | 0.429 | 0.46  | 0.355 |     0.319 | Chronos |        0.0365 |
| validation            | day-ahead |    1120 |          8 | 0.578 | 0.427 | 0.367 | 0.384 |     0.301 | Chronos |        0.0666 |
| test                  | +1h       |    1336 |          8 | 1.266 | 1.166 | 0.93  | 1.032 |     0.839 | Chronos |        0.0902 |
| test                  | +6h       |    1336 |          8 | 1.267 | 1.167 | 1.887 | 1.175 |     1.131 | Chronos |        0.0353 |
| test                  | day-ahead |    1336 |          8 | 1.267 | 1.166 | 1.162 | 1.173 |     1.118 | Chronos |        0.044  |
| test without 2 events | +1h       |    1295 |          8 | 0.49  | 0.389 | 0.336 | 0.265 |     0.319 | GBM     |        0.0544 |
| test without 2 events | +6h       |    1295 |          8 | 0.491 | 0.39  | 0.698 | 0.398 |     0.359 | Chronos |        0.0308 |
| test without 2 events | day-ahead |    1295 |          8 | 0.491 | 0.389 | 0.401 | 0.395 |     0.35  | Chronos |        0.0397 |

## Circuits where Chronos has the lower MAE
| block                 | horizon   | Chronos better than B1   | Chronos better than B2   | Chronos better than B3   | Chronos better than GBM   |
|:----------------------|:----------|:-------------------------|:-------------------------|:-------------------------|:--------------------------|
| validation            | +1h       | 8/8                      | 8/8                      | 7/8                      | 5/8                       |
| validation            | +6h       | 8/8                      | 7/8                      | 7/8                      | 7/8                       |
| validation            | day-ahead | 8/8                      | 8/8                      | 7/8                      | 8/8                       |
| test                  | +1h       | 8/8                      | 8/8                      | 6/8                      | 6/8                       |
| test                  | +6h       | 8/8                      | 6/8                      | 8/8                      | 6/8                       |
| test                  | day-ahead | 8/8                      | 7/8                      | 6/8                      | 8/8                       |
| test without 2 events | +1h       | 7/8                      | 7/8                      | 6/8                      | 4/8                       |
| test without 2 events | +6h       | 8/8                      | 7/8                      | 8/8                      | 7/8                       |
| test without 2 events | day-ahead | 8/8                      | 7/8                      | 7/8                      | 8/8                       |

## Test MAE by circuit (Wh per hour, all hours)
| horizon   | series_id          |     B1 |     B2 |     B3 |    GBM |   Chronos |
|:----------|:-------------------|-------:|-------:|-------:|-------:|----------:|
| +1h       | NE|HVAC            |  10.44 |  10.39 |   8.8  |  10.29 |      7.32 |
| +1h       | NE|Plugs & Sockets |   5.65 |   3.93 |   4.69 |   2.84 |      2.95 |
| +1h       | NW|Emerg. Lighting |  29.3  |  29.72 |  26.46 |  28.59 |     24.74 |
| +1h       | NW|HVAC            |  37.69 |  43.86 |  15.81 |  14.19 |     13.6  |
| +1h       | NW|Hand Dryer      |   1.15 |   0.77 |   0.56 |   0.52 |      0.57 |
| +1h       | NW|Lighting        |  61.81 |  49.02 |  30.12 |  34.67 |     32.74 |
| +1h       | NW|Plugs & Sockets | 355.93 | 265.15 | 183.61 | 209.69 |    163.16 |
| +1h       | NW|RACK            |   3.72 |   3.3  |   4.41 |   3.85 |      2.37 |
| +6h       | NE|HVAC            |  10.44 |  10.39 |  20.19 |  10.38 |     10.4  |
| +6h       | NE|Plugs & Sockets |   5.65 |   3.93 |   3.9  |   3.71 |      2.9  |
| +6h       | NW|Emerg. Lighting |  29.3  |  29.72 |  34.39 |  29.36 |     28.53 |
| +6h       | NW|HVAC            |  37.69 |  43.86 |  69.31 |  50.42 |     32.62 |
| +6h       | NW|Hand Dryer      |   1.15 |   0.77 |   0.97 |   0.79 |      0.68 |
| +6h       | NW|Lighting        |  61.81 |  49.02 |  89.48 |  50.27 |     53.31 |
| +6h       | NW|Plugs & Sockets | 355.93 | 265.15 | 441.31 | 266.82 |    229.15 |
| +6h       | NW|RACK            |   3.72 |   3.3  |   3.29 |   2.79 |      2.34 |
| day-ahead | NE|HVAC            |  10.44 |  10.39 |  10.28 |  10.36 |     10.34 |
| day-ahead | NE|Plugs & Sockets |   5.65 |   3.93 |   4.31 |   4.66 |      3.05 |
| day-ahead | NW|Emerg. Lighting |  29.3  |  29.72 |  27.6  |  29.59 |     28.14 |
| day-ahead | NW|HVAC            |  37.69 |  43.86 |  37.88 |  44.44 |     29.69 |
| day-ahead | NW|Hand Dryer      |   1.15 |   0.77 |   0.82 |   0.73 |      0.67 |
| day-ahead | NW|Lighting        |  61.81 |  49.02 |  52.53 |  54.74 |     51.06 |
| day-ahead | NW|Plugs & Sockets | 355.93 | 265.15 | 322.12 | 258.65 |    246.09 |
| day-ahead | NW|RACK            |   3.72 |   3.3  |   3.51 |   2.68 |      2.35 |

## Day-ahead by hours ahead (scaled MAE, test without 2 events)
| bucket   |    B1 |    B2 |    B3 |   GBM |   Chronos |
|:---------|------:|------:|------:|------:|----------:|
| 1–3      | 0.453 | 0.336 | 0.322 | 0.315 |     0.326 |
| 4–6      | 0.465 | 0.353 | 0.405 | 0.343 |     0.298 |
| 7–12     | 0.551 | 0.474 | 0.438 | 0.463 |     0.409 |
| 13–18    | 0.505 | 0.431 | 0.442 | 0.42  |     0.394 |
| 19–24    | 0.446 | 0.308 | 0.36  | 0.368 |     0.284 |

## Chronos 10–90 % range
| split      | horizon   |   hours |   inside_10_90 |   below_q10 |   above_q90 |
|:-----------|:----------|--------:|---------------:|------------:|------------:|
| test       | +1h       |    1344 |          0.824 |       0.082 |       0.094 |
| test       | +6h       |    1344 |          0.801 |       0.089 |       0.109 |
| test       | day-ahead |    1344 |          0.801 |       0.086 |       0.113 |
| validation | +1h       |    1336 |          0.784 |       0.118 |       0.097 |
| validation | +6h       |    1336 |          0.793 |       0.106 |       0.101 |
| validation | day-ahead |    1336 |          0.793 |       0.112 |       0.096 |

## NE|HVAC run on 3 Oct vs Chronos q90
| horizon   |   event_hours |   above_q90 |   max_q90_Wh |   share of normal test hours above q90 |
|:----------|--------------:|------------:|-------------:|---------------------------------------:|
| +1h       |             3 |           1 |   1754.93    |                                  0.091 |
| +6h       |             3 |           3 |      3.34549 |                                  0.098 |
| day-ahead |             3 |           3 |      3.41095 |                                  0.101 |

## Validation tuning (context length)
|   ctx_len |    +1h |    +6h |   day-ahead |
|----------:|-------:|-------:|------------:|
|       168 | 0.2549 | 0.3488 |      0.3402 |
|       336 | 0.2561 | 0.3424 |      0.3338 |
|       504 | 0.2552 | 0.3386 |      0.3227 |
|       672 | 0.2558 | 0.3401 |      0.3266 |

Hours each model lost to the common mask: {'B1_last_week': 672, 'B2_weekday_hour_median': 0, 'B3_persistence': 0, 'ML_GBM': 0, 'ML_Chronos': 0}