# Sprint 3 — pretrained model: Chronos-Bolt (Small), zero-shot

```
pip install -r requirements.txt                 # Task 7&8 libraries + torch, chronos-forecasting, transformers, tabulate
# weights: put config.json + model.safetensors of chronos-bolt-small in weights/chronos-bolt-small/
python -m pytest -q tests/                      # 29 tests on toy data (26 Task 7&8 + 3 Chronos), no weights needed
python run_chronos_tune.py                      # validation only: choose context length, freeze (~1 min)
python run_chronos_test.py                      # frozen setting, test week once
python run_chronos_compare.py                   # B1, B2, B3, GBM, Chronos on the same hours -> results/chronos_*
```

Unzip `Chronos_rev0_26-10.zip` into the Task 7&8 folder (`Task78_rev0_19-10`): the scripts use its dataset, modules and Task 8 results. `requirements.txt` and `.gitignore` replace the Task 7&8 versions; both are supersets.

| File | What it does |
|---|---|
| `chronos_model.py` | Context builder (only hours before the issue time), Chronos calls, forecast rows in the Task 7/8 format plus q10/q90 |
| `run_chronos_tune.py` | Scores 4 context lengths on validation, freezes the best per horizon. Never builds test rows. Refuses to overwrite a freeze |
| `run_chronos_test.py` | Checks dataset + weights checksums, predicts the test week once |
| `run_chronos_compare.py` | B1, B2, B3, GBM and Chronos on the common mask; per circuit, by hours ahead, forecast ranges |
| `tests/test_chronos.py` | Leakage, missing hours, lead mapping (model call replaced by a stub) |
| `models/chronos_frozen_config.json` | Chosen context lengths, weights/dataset checksums, versions |
| `results/` | `chronos_comparison.xlsx`, `chronos_tables.md`, `chronos_tuning_log.csv`, validation/test predictions |

The weights (190 MB) are not in the repository (`.gitignore`); `run_chronos_test.py` checks their SHA-256.

## Why this model
The first ML model (GBM, Task 8) is fitted on 35 training days, so each weekday appears only about 5 times. Chronos-Bolt was pretrained on a large external collection of time series and is used **without fitting anything on our data**. The question it answers: does outside prior knowledge help when our own history is short?

## Setup
- **Model:** `chronos-bolt-small` (48M parameters, T5 encoder–decoder), CPU, deterministic (a rerun gives identical predictions).
- **Input:** only the hourly `energy_Wh` of one circuit for the hours that started before the issue time. Invalid hours stay NaN (masked by the model, not set to 0). No calendar, no other circuits.
- **Output:** 24 hourly quantiles per (circuit, issue time). +1h, +6h and day-ahead read leads 1, 6 and 1–24 from the same call. Point forecast = median (MAE-optimal); 0.1 / 0.9 kept as a range. Negative values clipped to 0.
- **Same forecasts as Tasks 7/8:** `forecast_tasks`, hourly issues for +1h/+6h, 00:00 Madrid for day-ahead.

## Protocol
- **Nothing is fitted** on training, validation or test, so §4/§9 hold trivially. The test-week context includes validation hours; this is allowed by the reworded §9 (inputs only, before the issue time) and is the same thing the GBM lag inputs do.
- **Selection on validation only,** with the Task 8 rule (lowest mean over circuits of MAE ÷ training mean). The only setting is the context length: 168 / 336 / 504 / 672 h. All four lengths are available at every validation and test issue time, so the tested setting is exactly the validated one.
- **Model size was not tuned:** only the Small weights were available (Hugging Face is not reachable from the work environment).

| Horizon | Context chosen | Validation score (own hours) |
|---|---|---|
| +1h | 168 h | 0.255 |
| +6h | 504 h | 0.339 |
| day-ahead | 504 h | 0.323 |

The +1h choice is a near tie (0.2549–0.2561 for all lengths).

## Results
Scaled MAE = MAE ÷ circuit training mean, averaged over the 8 circuits (lower is better). All five models are scored on exactly the same hours; the B1–B3 and GBM numbers reproduce the Task 8 tables exactly.

| set | horizon | B1 | B2 | B3 | GBM | **Chronos** | best |
|---|---|---|---|---|---|---|---|
| validation | +1h | 0.578 | 0.427 | 0.290 | **0.246** | **0.246** | GBM ≈ Chronos |
| validation | +6h | 0.578 | 0.429 | 0.460 | 0.355 | **0.319** | Chronos |
| validation | day-ahead | 0.578 | 0.427 | 0.367 | 0.384 | **0.301** | Chronos |
| test | +1h | 1.266 | 1.166 | 0.930 | 1.032 | **0.839** | Chronos |
| test | +6h | 1.267 | 1.167 | 1.887 | 1.175 | **1.131** | Chronos |
| test | day-ahead | 1.267 | 1.166 | 1.162 | 1.173 | **1.118** | Chronos |
| test without 2 events | +1h | 0.490 | 0.389 | 0.336 | **0.265** | 0.319 | GBM |
| test without 2 events | +6h | 0.491 | 0.390 | 0.698 | 0.398 | **0.359** | Chronos |
| test without 2 events | day-ahead | 0.491 | 0.389 | 0.401 | 0.395 | **0.350** | Chronos |

Validation +1h is a tie at three decimals; unrounded, Chronos is 0.2457 and GBM 0.2462 (difference 0.0005, well within the noise of one week). "Test without 2 events" = Task 8 sensitivity view (leaves out the NE|HVAC run on 3 Oct and the 18 NW|Emerg. Lighting hours with impossible energy readings); the official results keep them.

**Circuits where Chronos has the lower MAE (test without 2 events):**
| horizon | vs B2 | vs B3 | vs GBM |
|---|---|---|---|
| +1h | 7/8 | 6/8 | 4/8 |
| +6h | 7/8 | 8/8 | 7/8 |
| day-ahead | 7/8 | 7/8 | 8/8 |

**Day-ahead by hours ahead (scaled MAE, test without 2 events):**
| hours ahead | B1 | B2 | B3 | GBM | Chronos |
|---|---|---|---|---|---|
| 1–3 | 0.453 | 0.336 | 0.322 | **0.315** | 0.326 |
| 4–6 | 0.465 | 0.353 | 0.405 | 0.343 | **0.298** |
| 7–12 | 0.551 | 0.474 | 0.438 | 0.463 | **0.409** |
| 13–18 | 0.505 | 0.431 | 0.442 | 0.420 | **0.394** |
| 19–24 | 0.446 | 0.308 | 0.360 | 0.368 | **0.284** |

**Forecast range (10–90 %):** 78–82 % of actual values fall inside it in both weeks (target 80 %), so the range is well calibrated on normal hours.

## Interpretation
**Chronos is the strongest model at +6h and day-ahead.** On test without the events it is 8–10 % below the weekday-hour median (0.359 vs 0.390; 0.350 vs 0.389), where GBM was only level with B2. It beats GBM on 7–8 of 8 circuits. The same ranking holds in validation.

**At +1h it matches GBM but does not beat it.** Tied on validation; on test without the events GBM is better (0.265 vs 0.319). With the events included, Chronos is best (0.839 vs 0.930 for persistence), because it returns to the normal level quickly after the NE|HVAC run (NE|HVAC +1h MAE: Chronos 7.3, persistence 8.8, GBM 10.3 Wh).

**Why it helps.** Chronos adapts to the recent level of each circuit, not to patterns learned in training. That is where GBM failed: NW|HVAC on standby in validation (day-ahead MAE: Chronos 12.9 Wh, GBM 65.6 Wh, B2 77.5 Wh). The weekday-hour shape comes from its long context (504 h = 3 weeks was chosen for +6h and day-ahead).

## Review (26 Oct)
- **Clean rebuild:** unzipped onto a fresh `Task78_rev0_19-10` folder, tests → tune → test → compare reproduce every Chronos prediction and table exactly; the frozen config differs only in its timestamp.
- **Checks:** dataset and weights checksums match the freeze; every context hour starts before its issue time; the newest valid context hour is at most 2 h old; the selection scales equal the Task 8 frozen scales.
- **Fixed during review (no forecast or score changed):** the "best" label is now decided on unrounded values (column `best_margin`); the range width uses each horizon's own scale; a docstring wrongly said the weights checksum is checked on load; `transformers` and `tabulate` pinned.

## Issues and limitations
- **One test week.** The +6h gain is concentrated: on test without the events, Chronos beats B2 on only 3 of 8 Madrid days at +6h (day-ahead: 7 of 8). The day-ahead advantage is more consistent.
- **Model size not selected,** only Small was available. Adding sizes now needs either a validation-only sensitivity check or a protocol amendment, because the test week was already used.
- **Univariate:** no calendar or holiday input. No holidays fall in the data, so this is not tested.
- **The q90 alone is not an anomaly rule.** All 3 hours of the NE|HVAC run lie above the day-ahead q90 (about 3.4 Wh vs ~690 Wh actual), but by construction about 10 % of normal hours do too. A usable flag needs a much stricter threshold, chosen on validation.
- **Reproducibility checked on one environment** (torch 2.14.1, CPU run); another torch build or CPU may change the last decimals.
- **External model:** results depend on pretrained weights we did not train and cannot inspect; the report should cite the model and its version.

## Next steps (proposed)
1. GBM with the Chronos forecast and range as inputs (Chronos forecasts for training hours are honest because nothing is fitted), chosen on validation.
2. Quick check first: validation-weighted average of GBM and Chronos, or the best model per horizon.
3. Tiny/Mini/Base weights; size selected on validation.
4. Anomaly flag from the Chronos range, threshold chosen on validation (Sprint 3 item 6).
