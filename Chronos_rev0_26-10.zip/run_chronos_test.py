"""Sprint 3 — Chronos-Bolt: run the FROZEN configuration once on the test week.

    python run_chronos_test.py

Contains no selection code. Refuses to run if the frozen config is missing or the dataset / weights differ from
the checksums recorded at freezing time. Writes results/chronos_test_predictions.parquet.
"""
import json
from pathlib import Path

import pandas as pd

import config as C
import chronos_model as CM
from task7_pipeline import sha256_file
from task7_baselines import load_derived, forecast_tasks

FROZEN = Path("models/chronos_frozen_config.json")
if not FROZEN.exists():
    raise SystemExit("no frozen configuration — run run_chronos_tune.py first")
cfg = json.loads(FROZEN.read_text())
if sha256_file(C.DERIVED_PATH) != cfg["dataset"]["sha256"]:
    raise SystemExit("dataset differs from the one the configuration was frozen on")
if CM.sha256(CM.WEIGHTS_DIR / "model.safetensors") != cfg["weights"]["model_sha256"]:
    raise SystemExit("Chronos weights differ from the frozen ones")

S = cfg["series"]
h = load_derived(C.DERIVED_PATH)
h = h[h["series_id"].isin(S)]
grids = CM.series_grid(h)
pipe = CM.load_pipeline()
out = []
for hz, c in cfg["horizons"].items():
    t = forecast_tasks(h, hz, "test", S)
    out.append(CM.chronos_forecasts(pipe, h, t, c["ctx_len"], grids=grids))
TP = pd.concat(out, ignore_index=True)
TP.to_parquet("results/chronos_test_predictions.parquet", index=False)
print("wrote results/chronos_test_predictions.parquet", TP.shape,
      {hz: c["ctx_len"] for hz, c in cfg["horizons"].items()})
