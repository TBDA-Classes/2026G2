"""Sprint 3 — Chronos-Bolt: choose the context length on VALIDATION only, then freeze.

    python run_chronos_tune.py

Selection rule (fixed before running, same as Task 8): per horizon, the lowest mean over the
8 circuits of (validation MAE / circuit training mean). Only setting: context length (CTX_GRID). Model size is
fixed to Small (the only weights available). Never builds test rows. Refuses to overwrite an existing freeze.

Writes models/chronos_frozen_config.json, results/chronos_tuning_log.csv,
results/chronos_validation_predictions.parquet (chosen setting per horizon).
"""
import json
import platform
import time
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

import config as C
import chronos_model as CM
from task7_pipeline import sha256_file
from task7_baselines import load_derived, forecast_tasks
from task8_model import fit_cutoff, series_scale, scaled_mae_by_series

FROZEN = Path("models/chronos_frozen_config.json")
if FROZEN.exists():
    raise SystemExit(f"{FROZEN} exists — the configuration is frozen. Delete it deliberately to re-tune.")

h = load_derived(C.DERIVED_PATH)
S = json.loads(Path(C.FROZEN_CONFIG).read_text())["series"]          # same 8 circuits as Task 8
h = h[h["series_id"].isin(S)]
grids = CM.series_grid(h)
pipe = CM.load_pipeline()

tasks = {hz: forecast_tasks(h, hz, "validation", S) for hz in C.HORIZONS}
assert all((t["split"] == "validation").all() for t in tasks.values())
scales = {hz: series_scale(h, fit_cutoff(h, hz, S)) for hz in C.HORIZONS}
allt = pd.concat(tasks.values(), ignore_index=True)

log, preds = [], {}
for L in CM.CTX_GRID:
    t0 = time.time()
    P = CM.chronos_forecasts(pipe, h, allt, L, grids=grids)
    for hz in C.HORIZONS:
        Ph = P[P["horizon"] == hz]
        per = scaled_mae_by_series(Ph, scales[hz])
        preds[(hz, L)] = Ph
        log.append(dict(horizon=hz, ctx_len=L, score=per.mean(), n_series=len(per),
                        coverage=float((Ph["y_pred"].notna() & Ph["y_true"].notna()).sum() / Ph["y_true"].notna().sum()),
                        **{f"scaled_MAE|{s}": v for s, v in per.items()}))
    print(f"ctx {L}: {time.time() - t0:.0f}s  " + "  ".join(f"{r['horizon']} {r['score']:.4f}" for r in log[-3:]))

log = pd.DataFrame(log)
log.to_csv("results/chronos_tuning_log.csv", index=False)
best = log.loc[log.groupby("horizon")["score"].idxmin()].set_index("horizon")

import chronos, torch, transformers
cfg = dict(
    model=CM.MODEL, created_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
    rule="Zero-shot: nothing fitted on our data. Context length chosen on validation by mean_scaled_MAE "
         "(mean over series of MAE / series training mean). Test not used before freezing.",
    weights=dict(name="chronos-bolt-small (config _name_or_path: autogluon/chronos-bolt-small)",
                 model_sha256=CM.sha256(CM.WEIGHTS_DIR / "model.safetensors"),
                 config_sha256=CM.sha256(CM.WEIGHTS_DIR / "config.json")),
    dataset=dict(file=Path(C.DERIVED_PATH).name, version=C.DERIVED_VERSION, sha256=sha256_file(C.DERIVED_PATH)),
    series=S, splits_utc=C.SPLITS, day_ahead_issue="00:00 Europe/Madrid",
    point_forecast="median (0.5 quantile), clipped at 0", quantiles=CM.QUANTILES, prediction_length=CM.PRED_LEN,
    ctx_grid=CM.CTX_GRID,
    horizons={hz: dict(ctx_len=int(best.loc[hz, "ctx_len"]), validation_score=round(float(best.loc[hz, "score"]), 6),
                       scale_Wh=scales[hz].round(6).to_dict()) for hz in C.HORIZONS},
    versions=dict(python=platform.python_version(), chronos=chronos.__version__ if hasattr(chronos, "__version__") else "n/a",
                  torch=torch.__version__, transformers=transformers.__version__, pandas=pd.__version__),
)
FROZEN.write_text(json.dumps(cfg, indent=2))
VP = pd.concat([preds[(hz, cfg["horizons"][hz]["ctx_len"])] for hz in C.HORIZONS], ignore_index=True)
VP.to_parquet("results/chronos_validation_predictions.parquet", index=False)
pd.set_option("display.width", 200)
print(log.pivot(index="ctx_len", columns="horizon", values="score").round(4))
print("frozen:", {hz: v["ctx_len"] for hz, v in cfg["horizons"].items()})
