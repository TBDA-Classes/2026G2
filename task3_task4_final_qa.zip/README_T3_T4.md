# Storey 1 — Tasks 3 & 4 handover (dataset v1.0 FROZEN)
Upload together with the Task 1/2 files. Contents: `Task3_Task4_Final_QA_Summary.md` (read first), `Storey1_ALL_ZONES_FROZEN_v1.0.csv.gz`, `FROZEN_v1.0_MANIFEST.json`, `load_frozen_dataset.py`, `task3_task4_final_qa.py`, `freeze_dataset.py`, `results_t3_t4/`.

Reproduce:
```
python -m pip install pandas
python task3_task4_final_qa.py --merged Storey1_ALL_ZONES_MERGED.csv --zones-dir <folder with the 4 *_timestamps.csv>
python freeze_dataset.py --merged Storey1_ALL_ZONES_MERGED.csv --version 1.0 --expect-sha256 6355c0cd63157318d7e5693d9f9b08ce7574c81b5c1e8ce675050ac9f57d5aa0
```
Use the data: `from load_frozen_dataset import load_frozen; df = load_frozen("Storey1_ALL_ZONES_FROZEN_v1.0.csv.gz")`
