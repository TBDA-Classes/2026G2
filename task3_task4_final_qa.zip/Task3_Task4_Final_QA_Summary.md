# CeDInt Storey 1 — Sprint 2, Tasks 3 & 4: Merge validation and final QA (dataset freeze v1.0)

**Status: merge VALIDATED, dataset FROZEN as v1.0.** 21/21 automated checks pass (`task3_task4_final_qa.py`). Open points that do not block freezing are listed in section 5.

## 1. Scope and lineage
| Item | Value |
|---|---|
| Candidate merged file | `Storey1_ALL_ZONES_MERGED.csv` (named `...MERGED2.csv` in the Task 2 README) |
| SHA-256 (uncompressed) | `6355c0cd63157318d7e5693d9f9b08ce7574c81b5c1e8ce675050ac9f57d5aa0` — **identical to the input used in Task 2**, so Task 2 evidence applies to this exact file |
| Reference inputs | 4 Task 1 outputs `Storey1_{NE,NW,SE,SW}_CLEAN_DATA_timestamps.csv` + `timestamp_qa_report.csv` |
| Rows / columns / series | 1,273,456 / 27 / 17 (zone × sensor) |
| Not available to me | the original `CLEAN DATA all zones.zip` (upstream of Task 1). Lineage is therefore verified from the Task 1 zone files onward |

## 2. Task 3 — Merge validation
| Requirement | Result | Evidence |
|---|---|---|
| Merge correctly combines NE, NW, SE, SW | PASS. Every cell of every zone block equals its source zone file (0 differing cells, same order) | `T3_Row_Reconciliation.csv` |
| Schemas and naming aligned | PASS. 4 zone files share identical 26 columns in identical order; merged = `zone` + those 26 | `T4_Schema_Loaded_Dtypes.csv` |
| Traceable zone identifier | PASS. `zone` is present on every row, values only NE/NW/SE/SW; identity key `(zone, sensor, Timestamp)` has 0 duplicates | `T3_Row_Reconciliation.csv` |
| No unexplained row loss | PASS. NE 175,545 · NW 525,622 · SE 283,605 · SW 288,684 = 1,273,456, equal to zone files and to Task 1 QA report | `T3_Row_Reconciliation.csv` |
| Cleaned values, flags and provenance kept | PASS. 9 `*_flags` columns complete, integer, no NaN; `energy_source` complete; timestamps (UTC + Madrid) untouched | `T4_Missing_vs_Flags.csv` |
| Merge reproducible | PASS. Concatenating the 4 zone files (NE, NW, SE, SW) rebuilds a **byte-identical** file (same SHA-256) | script check |

## 3. Task 4 — Final QA
**Row counts per zone and period** (cut 2024-01-01 UTC, as in Task 2)

| Zone | Historical 2020-04 → 2023-02 (hourly) | Recent 2025-08-18 → 2025-10-13 (1-min) | Total |
|---|---|---|---|
| NE | 50,024 | 125,521 | 175,545 |
| NW | 147,065 | 378,557 | 525,622 |
| SE | 97,877 | 185,728 | 283,605 |
| SW | 110,416 | 178,268 | 288,684 |
| **All** | **405,382** | **868,074** | **1,273,456** |

Per-series counts: `T4_Rows_by_Series_Period.csv`. No data between 2023-02-28 and 2025-08-18 (Task 2 cross-regime hiatus, not touched).

**Missing values and flags**
- Identifiers, `Ea`, `Er`, `energy_source`, `E Device type`, `Number of Edevices`: 0 missing.
- **Every missing sensor value carries a non-zero quality flag, and no row with flag = 0 has a missing value** (W, I, Pa, Lum, Hum, Temp, Pres). Missingness is therefore documented, not silent.
- Missing % by zone (W / I / Lum / Hum / Temp): NE 0 / 6.6 / **100 / 100 / 100**; NW 0.1 / 0.7 / 11.3 / 7.6 / 7.6; SE 1.8 / 4.3 / 3.5 / 0.3 / 0.3; SW 1.1 / 2.1 / 3.1 / 0.2 / 0.4 (`T4_Missing_Pct_by_Zone.csv`, `T4_Missing_by_Series_Period.csv`).
- **NE has no environmental sensors**: Lum/Hum/Temp/Pres are 100 % missing with flag 131072 on all 175,545 rows.
- `energy_Wh` missing in 295 rows, all with `energy_source` = `period_start` (33) or `unknown` (262).
- Flag values are bit masks (e.g. 16384, 131072, 262144); full distribution in `T4_Flag_Distribution.csv`.

**Units, names, identifiers**
- `E Device type` == `sensor` on 100 % of rows (redundant but consistent); `Number of Edevices` constant within every series.
- No negative values in W, I, Pa, Ea, Er, energy; Hum within 0–100; Pres ∈ {0, 1}.
- UTC → Europe/Madrid conversion consistent on all rows (also 100 repeated local-hour rows = Task 2).
- **Traceability:** 17 series — NE 2 (HVAC, Plugs & Sockets), NW 6, SE 4, SW 5. The finest identifier available is `(zone, sensor)`; the data contain no separate circuit/device ID (`T4_Zone_Circuit_Traceability.csv`).

**Reproducibility:** the frozen file is byte-identical to the validated merge; the merge is rebuildable from the Task 1 zone files; the loader verifies the SHA-256 before use.

## 4. Frozen deliverables (v1.0)
| File | Purpose |
|---|---|
| `Storey1_ALL_ZONES_FROZEN_v1.0.csv.gz` (31.6 MB) | Frozen analytical dataset / modelling input. Uncompressed content = validated merge, unchanged (27 columns). Compressed because GitHub rejects files > 100 MB |
| `FROZEN_v1.0_MANIFEST.json` | SHA-256 (CSV and .gz), rows, columns, identity key |
| `load_frozen_dataset.py` | Official loader: checks checksum, adds `utc`, `series_id`, `regime` at load time (nothing is added to the frozen file) |
| `task3_task4_final_qa.py`, `freeze_dataset.py` | Reproduce all checks / the freeze |
| `results_t3_t4/` | Evidence CSVs + `QA_summary.json` |

## 5. Findings the modelling team must know (not blockers)
1. **Cumulative counters are not continuous across regimes.** `Ea` drops sharply at the first 2025 row in 16 of 17 series (`T4_Ea_Counter_Decreases.csv`, e.g. NW Plugs & Sockets 36.5 M → 1.28 M). Never difference `Ea`/`Er` across 2023 → 2025; use `energy_Wh` (derived, with `energy_source`) or work within a regime. The relationship between `Ea` increments and `energy_Wh` is not 1:1 in the historical data and should be confirmed with the data owner.
2. **Units are not documented in the files I received.** Names suggest W, A (I), VA (Pa), lux (Lum), %RH (Hum), °C (Temp), Pres = presence 0/1, `energy_Wh`/`apparent_energy_VAh`, but these are assumptions to confirm before publishing a data dictionary. Flag bit meanings are also not in the received files (the cleaning notebook defines them).
3. **SW RACK** has only historical data (13,038 rows, 2020-04-03 → 2021-12-03) and no 2025 data. NE has no environmental variables (see §3).
4. **Cadence/gap treatment and modelling target remain open decisions** from Task 2 (expected cadence, resolution, sensor scope). The freeze does not fill, drop or resample anything.
5. **Naming:** the file is called `MERGED` here and `MERGED2` in the Task 2 README (same SHA-256). Frozen name is `Storey1_ALL_ZONES_FROZEN_v1.0`. Column names with spaces (`E Device type`, `Number of Edevices`) are kept as-is for compatibility; `load_frozen(..., snake_case=True)` offers aliases.

## 6. Usage rules for colleagues
- Load only with `load_frozen_dataset.py`; do not edit the frozen file — any change means a new version (v1.1) with a new manifest.
- Sort/merge on `utc` (from `Timestamp`); use `timestamp_madrid` only for calendar features (join `upm_calendar.xlsx` on the Madrid date).
- Respect `*_flags`: filter or model them explicitly, do not treat NaN as zero.
