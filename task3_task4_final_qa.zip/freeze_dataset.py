"""Freeze the validated merged dataset (Task 4).
Usage: python freeze_dataset.py --merged Storey1_ALL_ZONES_MERGED.csv --version 1.0 [--output-dir frozen]
Creates Storey1_ALL_ZONES_FROZEN_v<version>.csv.gz (content byte-identical to the validated merge, deterministic gzip)
and FROZEN_v<version>_MANIFEST.json (sha256 of CSV and of .gz, rows, columns). Refuses to run if the sha256 does not match --expect-sha256 (if given).
"""
import argparse, gzip, hashlib, json, shutil
from pathlib import Path

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()

ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument("--merged", type=Path, required=True)
ap.add_argument("--version", default="1.0")
ap.add_argument("--expect-sha256", default=None)
ap.add_argument("--output-dir", type=Path, default=Path("frozen"))
a = ap.parse_args()
src_sha = sha(a.merged)
if a.expect_sha256 and src_sha != a.expect_sha256:
    raise SystemExit(f"sha256 mismatch: {src_sha} != {a.expect_sha256}")
a.output_dir.mkdir(parents=True, exist_ok=True)
gz = a.output_dir / f"Storey1_ALL_ZONES_FROZEN_v{a.version}.csv.gz"
with open(a.merged, "rb") as fi, open(gz, "wb") as raw, gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=9, mtime=0) as fo:
    shutil.copyfileobj(fi, fo, 1 << 20)          # mtime=0 and no filename -> reproducible .gz
with gzip.open(gz, "rb") as f:                    # verify round trip
    h = hashlib.sha256()
    n = 0
    for b in iter(lambda: f.read(1 << 20), b""):
        h.update(b); n += b.count(b"\n")
assert h.hexdigest() == src_sha, "round-trip sha mismatch"
header = open(a.merged, encoding="utf-8").readline().strip().split(",")
manifest = dict(dataset="Storey1_ALL_ZONES", version=a.version, status="FROZEN",
                csv_sha256_uncompressed=src_sha, gz_file=gz.name, gz_sha256=sha(gz), gz_bytes=gz.stat().st_size,
                data_rows=n - 1, n_columns=len(header), columns=header, line_terminator="CRLF",
                identity_key=["zone", "sensor", "Timestamp"], time_basis="Timestamp = UTC; timestamp_madrid = Europe/Madrid wall clock")
(a.output_dir / f"FROZEN_v{a.version}_MANIFEST.json").write_text(json.dumps(manifest, indent=2))
print(json.dumps({k: v for k, v in manifest.items() if k != "columns"}, indent=2))
