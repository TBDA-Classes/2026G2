"""Official loader for the frozen Storey 1 dataset (use this instead of ad-hoc pd.read_csv).

    from load_frozen_dataset import load_frozen
    df = load_frozen("Storey1_ALL_ZONES_FROZEN_v1.0.csv.gz")          # verifies sha256 against the manifest
    df = load_frozen(path, snake_case=True)                         # optional snake_case column aliases

Adds (derived at load time, NOT stored in the frozen file):
  utc         tz-aware UTC datetime from `Timestamp`  (identity/sort/merge key)
  series_id   "<zone>|<sensor>"
  regime      "historical_2020_2023" (nominal 60 min) | "recent_2025" (nominal 1 min)  [Task 2 split, cut 2024-01-01 UTC]
Rules: sort/merge on `utc`, never on `timestamp_madrid`; do NOT diff cumulative counters (Ea, Er) across regimes.
"""
import hashlib, json
from pathlib import Path
import numpy as np
import pandas as pd

CUT = pd.Timestamp("2024-01-01", tz="UTC")

def _sha_gz_content(path):
    import gzip
    h = hashlib.sha256()
    with gzip.open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()

def load_frozen(path, manifest=None, verify=True, snake_case=False):
    path = Path(path)
    manifest = Path(manifest) if manifest else next(path.parent.glob("FROZEN_v*_MANIFEST.json"), None)
    if verify and manifest and manifest.is_file():
        expected = json.loads(manifest.read_text())["csv_sha256_uncompressed"]
        got = _sha_gz_content(path)
        if got != expected:
            raise ValueError(f"Frozen dataset checksum mismatch: {got} != {expected}")
    df = pd.read_csv(path, low_memory=False)           # gzip inferred from extension
    df["utc"] = pd.to_datetime(df["Timestamp"], utc=True)
    df["series_id"] = df["zone"] + "|" + df["sensor"]
    df["regime"] = np.where(df["utc"] < CUT, "historical_2020_2023", "recent_2025")
    if snake_case:
        df = df.rename(columns={"E Device type": "e_device_type", "Number of Edevices": "number_of_edevices",
                                "Timestamp": "timestamp_utc", "W": "w", "I": "i", "Ea": "ea", "Er": "er", "Pa": "pa",
                                "Lum": "lum", "Hum": "hum", "Temp": "temp", "Pres": "pres"})
    return df
