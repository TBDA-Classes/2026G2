"""CeDInt Storey 1 - Sprint 2, Task 3 (merge validation) + Task 4 (final QA before freeze).

Usage:
  python task3_task4_final_qa.py --merged Storey1_ALL_ZONES_MERGED.csv --zones-dir <folder with the 4 *_timestamps.csv> [--output-dir results_t3_t4]

Read-only on all inputs. Writes evidence CSVs + QA_summary.json to the output dir.
Exit code 1 if any hard check FAILS. Requires: pandas.
"""
import argparse, hashlib, json, sys
from pathlib import Path
import numpy as np
import pandas as pd

ZONES = ["NE", "NW", "SE", "SW"]
CUT = pd.Timestamp("2024-01-01", tz="UTC")           # same regime split as Task 2
VALUE_COLS = ["W", "I", "Ea", "Er", "Pa", "Lum", "Hum", "Temp", "Pres", "energy_Wh", "apparent_energy_VAh"]
FLAG_OF = {"W": "W_flags", "I": "I_flags", "Ea": "Ea_flags", "Er": "Er_flags", "Pa": "Pa_flags",
           "Lum": "Lum_flags", "Hum": "Hum_flags", "Temp": "Temp_flags", "Pres": "Pres_flags"}
EXPECTED_TASK2_ROWS = {"NE": 175545, "NW": 525622, "SE": 283605, "SW": 288684}  # timestamp_qa_report.csv (Task 1)
RESULTS, CHECKS = {}, []


def sha256(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(chunk), b""):
            h.update(b)
    return h.hexdigest()


def check(name, ok, detail=""):
    CHECKS.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    print(f"{'PASS' if ok else 'FAIL'}: {name}" + (f" - {detail}" if detail else ""))
    return ok


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--merged", type=Path, required=True)
    ap.add_argument("--zones-dir", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, default=Path("results_t3_t4"))
    a = ap.parse_args()
    out = a.output_dir; out.mkdir(parents=True, exist_ok=True)

    zone_paths = {z: a.zones_dir / f"Storey1_{z}_CLEAN_DATA_timestamps.csv" for z in ZONES}
    for p in [a.merged, *zone_paths.values()]:
        if not p.is_file():
            sys.exit(f"Missing input: {p}")

    # ---------- inventory / lineage ----------
    inv = [{"file": p.name, "bytes": p.stat().st_size, "sha256": sha256(p)} for p in [a.merged, *zone_paths.values()]]
    pd.DataFrame(inv).to_csv(out / "T3_Input_Inventory.csv", index=False)
    RESULTS["merged_sha256"] = inv[0]["sha256"]

    # all columns as text first: lets us compare cell-by-cell with no float/NaN reinterpretation
    m_txt = pd.read_csv(a.merged, dtype=str, keep_default_na=False)
    z_txt = {z: pd.read_csv(p, dtype=str, keep_default_na=False) for z, p in zone_paths.items()}

    # ================= TASK 3 =================
    print("\n--- TASK 3: merge validation ---")
    # 3.1 schema alignment
    ref_cols = list(z_txt["NE"].columns)
    check("T3 schema identical across the 4 zone files (names + order)", all(list(z.columns) == ref_cols for z in z_txt.values()))
    check("T3 merged schema = ['zone'] + zone schema", list(m_txt.columns) == ["zone"] + ref_cols, f"{len(m_txt.columns)} columns")
    check("T3 no whitespace/case variants in sensor labels", all(s == s.strip() for s in m_txt.sensor.unique()))

    # 3.2 zone identifier
    zc = m_txt.zone.value_counts().to_dict()
    check("T3 zone id present on every row and limited to NE/NW/SE/SW", set(zc) == set(ZONES) and sum(zc.values()) == len(m_txt), str(zc))

    # 3.3 row accounting + 3.4 cell-by-cell equality
    rows = []
    for z in ZONES:
        mz = m_txt[m_txt.zone == z].drop(columns="zone").reset_index(drop=True)
        zz = z_txt[z]
        same_n = len(mz) == len(zz)
        diff_cells = int((mz.values != zz.values).sum()) if same_n else -1
        rows.append(dict(zone=z, zone_file_rows=len(zz), merged_rows=len(mz), task1_report_rows=EXPECTED_TASK2_ROWS[z],
                         rows_lost=len(zz) - len(mz), cells_different=diff_cells,
                         sensors=zz.sensor.nunique(), series_keys=zz.groupby("sensor").ngroups))
    rec = pd.DataFrame(rows); rec.to_csv(out / "T3_Row_Reconciliation.csv", index=False)
    check("T3 row count per zone: zone file == merged == Task 1 QA report", bool(((rec.zone_file_rows == rec.merged_rows) & (rec.merged_rows == rec.task1_report_rows)).all()),
          f"total {int(rec.merged_rows.sum()):,}")
    check("T3 every cell in merged equals its source zone file (values, flags, timestamps, order)", bool((rec.cells_different == 0).all()), f"differing cells: {int(rec.cells_different.sum())}")
    check("T3 no duplicate (zone, sensor, Timestamp)", int(m_txt.duplicated(["zone", "sensor", "Timestamp"]).sum()) == 0)

    # 3.5 reproducibility of the merge itself: rebuild from the zone files and compare bytes
    rebuilt = pd.concat([z_txt[z].assign(zone=z)[["zone"] + ref_cols] for z in ZONES], ignore_index=True)
    rebuilt_csv = rebuilt.to_csv(index=False, lineterminator="\r\n").encode()
    rb_sha = hashlib.sha256(rebuilt_csv).hexdigest()
    check("T3 merge is reproducible: concat NE,NW,SE,SW zone files -> byte-identical to merged", rb_sha == RESULTS["merged_sha256"], f"rebuilt sha256 {rb_sha[:16]}...")
    del rebuilt, rebuilt_csv

    # ---- typed load for numeric checks ----
    m = pd.read_csv(a.merged, low_memory=False)
    m["utc"] = pd.to_datetime(m["Timestamp"], utc=True)
    m["period"] = np.where(m["utc"] < CUT, "historical_2020_2023", "recent_2025")
    m["series_id"] = m["zone"] + "|" + m["sensor"]
    flag_cols = [c for c in m.columns if c.endswith("_flags")]

    # 3.6 values + flags preserved: flags are integer, no NaN; every NaN value has a non-zero flag, flag==0 never has NaN
    check("T3 flag columns complete (9 columns, no NaN, integer-valued)", len(flag_cols) == 9 and not m[flag_cols].isna().any().any()
          and bool((m[flag_cols] % 1 == 0).all().all()))
    rows = []
    for v, f in FLAG_OF.items():
        nan = m[v].isna(); fl = m[f] != 0
        rows.append(dict(variable=v, flag_col=f, nan_values=int(nan.sum()), nan_with_zero_flag=int((nan & ~fl).sum()),
                         nonzero_flag_rows=int(fl.sum()), nonzero_flag_with_value=int((fl & ~nan).sum())))
    mf = pd.DataFrame(rows); mf.to_csv(out / "T4_Missing_vs_Flags.csv", index=False)
    check("T3/4 every missing sensor value is explained by a non-zero quality flag", int(mf.nan_with_zero_flag.sum()) == 0)

    # ================= TASK 4 =================
    print("\n--- TASK 4: final QA ---")
    # 4.1 counts per zone / period / series
    cnt_zp = m.groupby(["zone", "period"]).agg(rows=("utc", "size"), first_utc=("utc", "min"), last_utc=("utc", "max")).reset_index()
    cnt_zp.to_csv(out / "T4_Rows_by_Zone_Period.csv", index=False)
    cnt_s = m.groupby(["zone", "sensor", "period"]).agg(rows=("utc", "size"), first_utc=("utc", "min"), last_utc=("utc", "max")).reset_index()
    cnt_s.to_csv(out / "T4_Rows_by_Series_Period.csv", index=False)
    check("T4 row counts add up (zone x period = total)", int(cnt_zp.rows.sum()) == len(m) == int(cnt_s.rows.sum()), f"{len(m):,} rows, {m.series_id.nunique()} series")
    check("T4 only the two known periods are present (2020-2023 / 2025)", set(m.utc.dt.year.unique()) <= {2020, 2021, 2022, 2023, 2025})

    # 4.2 missing values
    miss = []
    for keys, g in m.groupby(["zone", "sensor", "period"]):
        d = dict(zone=keys[0], sensor=keys[1], period=keys[2], rows=len(g))
        for c in VALUE_COLS + ["energy_source"]:
            d[f"{c}_missing"] = int(g[c].isna().sum())
        miss.append(d)
    pd.DataFrame(miss).to_csv(out / "T4_Missing_by_Series_Period.csv", index=False)
    m.groupby("zone")[VALUE_COLS].apply(lambda g: (g.isna().mean() * 100).round(2)).to_csv(out / "T4_Missing_Pct_by_Zone.csv")
    key_cols = ["zone", "sensor", "Timestamp", "timestamp_madrid", "Ea", "Er", "energy_source", "E Device type", "Number of Edevices"]
    check("T4 no missing in identifiers/keys/Ea/Er/energy_source", int(m[key_cols].isna().sum().sum()) == 0)
    ne_env = m[m.zone == "NE"][["Lum", "Hum", "Temp", "Pres"]].isna().all().all()
    check("T4 INFO NE has no environmental sensors (Lum/Hum/Temp/Pres 100% missing, flag 131072)", bool(ne_env) and bool((m[m.zone == "NE"]["Temp_flags"] == 131072).all()))

    # 4.3 flag review
    long = []
    for f in flag_cols:
        vc = m.groupby(["zone", f]).size().reset_index(name="rows").rename(columns={f: "flag_value"})
        vc.insert(1, "flag_column", f); long.append(vc)
    pd.concat(long).to_csv(out / "T4_Flag_Distribution.csv", index=False)

    # 4.4 units / names / identifiers
    check("T4 'E Device type' == sensor on every row (redundant label, consistent)", bool((m["E Device type"] == m["sensor"]).all()))
    check("T4 'Number of Edevices' constant within each (zone, sensor) series", int(m.groupby("series_id")["Number of Edevices"].nunique().max()) == 1)
    check("T4 physical ranges plausible (no negatives in W,I,Pa,energy; Hum 0-100; Pres in {0,1})",
          bool((m[["W", "I", "Pa", "Ea", "Er", "energy_Wh", "apparent_energy_VAh"]].min() >= 0).all()
               and m.Hum.dropna().between(0, 100).all() and set(m.Pres.dropna().unique()) <= {0.0, 1.0}))
    check("T4 energy_Wh missing only where energy_source in {period_start, unknown}",
          bool(m.loc[m.energy_Wh.isna(), "energy_source"].isin(["period_start", "unknown"]).all()))
    check("T4 UTC -> Madrid conversion consistent on all rows",
          bool((m.utc.dt.tz_convert("Europe/Madrid").dt.tz_localize(None) == pd.to_datetime(m.timestamp_madrid)).all()))
    m = m.sort_values(["series_id", "utc"])
    m["dEa"] = m.groupby("series_id")["Ea"].diff()
    dec = m.loc[m.dEa < 0, ["zone", "sensor", "Timestamp", "Ea", "dEa"]]
    dec.to_csv(out / "T4_Ea_Counter_Decreases.csv", index=False)
    check("T4 INFO cumulative counter Ea decreases (counter resets)", True, f"{len(dec)} events across {dec.groupby(['zone','sensor']).ngroups} series (see T4_Ea_Counter_Decreases.csv)")
    pd.DataFrame({"column": m.columns.drop(["utc", "period", "series_id", "dEa"]), "dtype_loaded": [str(m[c].dtype) for c in m.columns.drop(["utc", "period", "series_id", "dEa"])]}
                 ).to_csv(out / "T4_Schema_Loaded_Dtypes.csv", index=False)

    # 4.5 traceability
    tr = m.groupby(["zone", "sensor"]).agg(rows=("utc", "size"), n_edevices=("Number of Edevices", "first")).reset_index()
    tr.to_csv(out / "T4_Zone_Circuit_Traceability.csv", index=False)
    check("T4 17 traceable series (zone, sensor) with expected layout", len(tr) == 17 and sorted(tr.zone.unique()) == ZONES,
          tr.groupby("zone").size().to_dict().__str__())

    n_fail = sum(c["status"] == "FAIL" for c in CHECKS)
    RESULTS.update(rows=len(m), series=int(m.series_id.nunique()), checks=CHECKS, failed=n_fail)
    (out / "QA_summary.json").write_text(json.dumps(RESULTS, indent=2, default=str))
    print(f"\nRESULT: {len(CHECKS) - n_fail}/{len(CHECKS)} checks PASS, {n_fail} FAIL. Evidence in {out.resolve()}")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
