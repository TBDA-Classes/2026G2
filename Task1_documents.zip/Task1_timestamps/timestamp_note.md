# Sprint 2 – Task 1: Timestamp convention (NE, NW, SE, SW)

**Script:** `standardise_timestamps.py` · **Input:** `CLEAN DATA all zones.zip` (branch Data-cleaning-process) · **Output:** `Storey1_<ZONE>_CLEAN_DATA_timestamps.csv` + `timestamp_qa_report.csv`

## Convention
- The source `Timestamp` column is **UTC** (no daylight-saving time). It is kept unchanged.
- One column is added to every zone file, right after `Timestamp`:

| Column | Meaning | Example |
|---|---|---|
| `timestamp_madrid` | same moment in Europe/Madrid local time (CET in winter, CEST in summer), no offset suffix so Excel reads it as a date | `2021-01-02 00:00:00` |

- **Join `upm_calendar.xlsx` on the Madrid date** (first 10 characters of `timestamp_madrid`), not on the UTC date.
- Rule: **store, sort and merge on UTC** (it has no gaps or repeated hours). **Use Madrid time only for human/calendar features** (date, hour, weekday, holiday, office hours).

## Evidence that the source is UTC
1. **No DST jumps.** On every spring-forward day (28 Mar 2021, 27 Mar 2022) and fall-back day (25 Oct 2020, 31 Oct 2021, 30 Oct 2022) every series has exactly 24 hourly rows. Local Madrid time would give 23 and 25.
2. **Sunset/sunrise anchor.** NW Lighting behaves like night lighting (on at night, off by day). Weekday mean per hour, 2020–2023:
   - Jan–Feb: switches on between 17:00 and 18:00, off between 07:00 and 08:00. Madrid sunset ≈ 18:00–18:30 CET = 17:00–17:30 UTC; sunrise ≈ 08:30 CET = 07:30 UTC.
   - Jun–Jul: switches on between 19:00 and 20:00, off between 04:00 and 05:00. Madrid sunset ≈ 21:45 CEST = 19:45 UTC; sunrise ≈ 06:45 CEST = 04:45 UTC.
   - Both seasons match UTC. Local time would put the summer switch-on at ~21–22h; a fixed CET clock at ~20–21h.
3. The cleaning notebook (v4) also reports occupancy in UTC.

## DST treatment
- Because the source is UTC, there are **no missing or duplicated source timestamps** at DST changes.
- After conversion, the October fall-back night shows the same Madrid clock time twice (e.g. 25 Oct 2020: 00:00 UTC → 02:00 summer time and 01:00 UTC → 02:00 winter time). These rows stay distinct through the original UTC `Timestamp`, so always sort and merge on `Timestamp`. Count per zone: see `rows_in_repeated_local_hour`.
- In spring the local hour 02:00–02:59 simply does not occur. Nothing is invented.

## QA results (`timestamp_qa_report.csv`)

| Zone | Rows | First (UTC) | Last (UTC) | Invalid | Duplicate sensor+time | Rows in repeated local hour | Rows whose date changes |
|---|---|---|---|---|---|---|---|
| NE | 175,545 | 2020-04-02 23:00 | 2025-10-13 14:35 | 0 | 0 | 12 | 13,976 |
| NW | 525,622 | 2020-04-02 23:00 | 2025-10-13 14:35 | 0 | 0 | 36 | 41,884 |
| SE | 283,605 | 2020-04-02 23:00 | 2025-10-13 14:35 | 0 | 0 | 24 | 24,251 |
| SW | 288,684 | 2020-04-02 23:00 | 2025-10-13 14:34 | 0 | 0 | 28 | 24,844 |

"Rows whose date changes" are rows between 22:00/23:00 and midnight UTC that belong to the **next** day in Madrid. This is why the calendar must be joined on the Madrid date (from `timestamp_madrid`), not on the UTC date.

## Open points for Task 2
- Two sampling regimes (hourly until 2023-02-28, ~1-minute from 2025-08-18) and the gap in between are not changed here; they belong to the temporal QA (Task 2).
- No new timestamps were created and no rows were removed.
