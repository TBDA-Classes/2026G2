"""
Sprint 2 - Task 1: Standardise timestamps
=========================================

Input : the 4 clean zone files from "CLEAN DATA all zones.zip"
        (NE/clean_Storey1_NE_CLEAN_DATA.csv, NW/..., SE/..., SW/...)
Output: one file per zone with 1 extra column, timestamp_madrid (right after Timestamp),
        plus a small QA report.

Convention (see timestamp_note.md for the evidence):
  - The original `Timestamp` column is UTC (no daylight-saving time).
  - We keep `Timestamp` exactly as it was (it is the UTC time), and add:
      timestamp_madrid  the same moment in Madrid local time (CET in winter, CEST in summer),
                        written without an offset so Excel reads it as a date.
                        In the October "clock goes back" night one Madrid hour occurs
                        twice; the original UTC Timestamp keeps those rows apart.
  - Use timestamp_madrid for calendar features: its first 10 characters are the
    local date to join upm_calendar.xlsx on.

Usage:
  python standardise_timestamps.py <folder with the NE/NW/SE/SW folders> <output folder>
"""
import sys
from pathlib import Path

import pandas as pd

SOURCE_TZ = "UTC"            # the timezone the sensor platform writes in
LOCAL_TZ = "Europe/Madrid"   # the timezone of the building (handles summer/winter time)
ZONES = ["NE", "NW", "SE", "SW"]


def standardise(df):
    # 1. Read the text as a date. Anything that is not a valid date becomes NaT.
    ts = pd.to_datetime(df["Timestamp"], format="%Y-%m-%d %H:%M:%S", errors="coerce")

    # 2. Say which timezone these times are in (UTC), then convert to Madrid time.
    utc = ts.dt.tz_localize(SOURCE_TZ)
    madrid = utc.dt.tz_convert(LOCAL_TZ)

    # 3. Add the new column. The original Timestamp column is not changed.
    df["timestamp_madrid"] = madrid.dt.strftime("%Y-%m-%d %H:%M:%S")

    # 4. Put the time columns at the front: sensor, Timestamp, timestamp_madrid.
    front = ["sensor", "Timestamp", "timestamp_madrid"]
    df = df[front + [c for c in df.columns if c not in front]]
    return df, ts, madrid


def qa(zone, df, ts, madrid):
    """Count the things Task 1 asks us to report."""
    invalid = int(ts.isna().sum())                                  # not a valid date
    duplicates = int(df.duplicated(["sensor", "Timestamp"]).sum())  # same sensor, same time twice
    # Rows whose Madrid clock time happens twice (the October night the clock goes back).
    # They are NOT a problem: the UTC time and the +01:00/+02:00 offset keep them unique.
    moments = pd.DataFrame({"utc": ts, "local": madrid.dt.tz_localize(None)}).drop_duplicates("utc")
    repeated = moments.loc[moments["local"].duplicated(keep=False), "utc"]
    repeated_local = int(ts.isin(repeated).sum())
    # Days where the calendar date changes because of the conversion (e.g. 23:30 UTC -> next day).
    date_shift = int((ts.dt.date != madrid.dt.date).sum())
    return {
        "zone": zone,
        "rows": len(df),
        "first_utc": ts.min(),
        "last_utc": ts.max(),
        "invalid_timestamps": invalid,
        "duplicate_sensor_timestamps": duplicates,
        "rows_in_repeated_local_hour": repeated_local,
        "rows_whose_date_changes": date_shift,
    }


def main(in_dir, out_dir):
    in_dir, out_dir = Path(in_dir), Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    report = []
    for zone in ZONES:
        src = in_dir / zone / f"clean_Storey1_{zone}_CLEAN_DATA.csv"
        print(f"{zone}: reading {src}")
        df = pd.read_csv(src, low_memory=False)
        df, ts, madrid = standardise(df)
        report.append(qa(zone, df, ts, madrid))
        dst = out_dir / f"Storey1_{zone}_CLEAN_DATA_timestamps.csv"
        df.to_csv(dst, index=False)
        print(f"{zone}: wrote {dst} ({len(df):,} rows)")
    rep = pd.DataFrame(report)
    rep.to_csv(out_dir / "timestamp_qa_report.csv", index=False)
    print(rep.to_string(index=False))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
